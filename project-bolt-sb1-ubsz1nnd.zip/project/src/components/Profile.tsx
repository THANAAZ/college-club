import React, { useState } from 'react';
import { User, Mail, GraduationCap, Building, Award, Users, Calendar, Lightbulb, Edit3, Save, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function Profile() {
  const { user, updateUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [editedUser, setEditedUser] = useState(user);

  const handleSave = () => {
    if (editedUser) {
      updateUser(editedUser);
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditedUser(user);
    setIsEditing(false);
  };

  const stats = [
    { label: 'Clubs Joined', value: user?.enrolledClubs?.length || 0, icon: Users },
    { label: 'Events Attended', value: 12, icon: Calendar },
    { label: 'Ideas Proposed', value: 3, icon: Lightbulb },
    { label: 'Achievements', value: 8, icon: Award }
  ];

  const achievements = [
    { title: 'Early Adopter', description: 'One of the first 100 users', date: 'Dec 2024', color: 'blue' },
    { title: 'Active Member', description: 'Attended 10+ events', date: 'Dec 2024', color: 'green' },
    { title: 'Innovator', description: 'Proposed 3 accepted ideas', date: 'Nov 2024', color: 'purple' },
    { title: 'Team Player', description: 'Joined 2+ clubs', date: 'Nov 2024', color: 'orange' }
  ];

  const recentActivity = [
    { action: 'Joined Coding Club', date: '2 days ago', type: 'join' },
    { action: 'Attended Tech Fest 2024', date: '5 days ago', type: 'event' },
    { action: 'Proposed AI Study Groups idea', date: '1 week ago', type: 'idea' },
    { action: 'Completed profile setup', date: '2 weeks ago', type: 'profile' }
  ];

  if (!user) return null;

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-8 text-white mb-8">
        <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-6">
          <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
            <span className="text-3xl font-bold text-white">
              {user.name?.split(' ').map(n => n[0]).join('')}
            </span>
          </div>
          <div className="flex-1">
            {isEditing ? (
              <div className="space-y-3">
                <input
                  type="text"
                  value={editedUser?.name || ''}
                  onChange={(e) => setEditedUser(prev => prev ? { ...prev, name: e.target.value } : null)}
                  className="text-3xl font-bold bg-white/20 border border-white/30 rounded-lg px-3 py-2 text-white placeholder-white/70"
                  placeholder="Your Name"
                />
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <input
                    type="text"
                    value={editedUser?.year || ''}
                    onChange={(e) => setEditedUser(prev => prev ? { ...prev, year: e.target.value } : null)}
                    className="bg-white/20 border border-white/30 rounded-lg px-3 py-2 text-white placeholder-white/70"
                    placeholder="Year"
                  />
                  <input
                    type="text"
                    value={editedUser?.department || ''}
                    onChange={(e) => setEditedUser(prev => prev ? { ...prev, department: e.target.value } : null)}
                    className="bg-white/20 border border-white/30 rounded-lg px-3 py-2 text-white placeholder-white/70"
                    placeholder="Department"
                  />
                </div>
              </div>
            ) : (
              <>
                <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
                <div className="flex flex-wrap items-center gap-4 text-white/90">
                  <div className="flex items-center space-x-2">
                    <GraduationCap className="w-5 h-5" />
                    <span>{user.year}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Building className="w-5 h-5" />
                    <span>{user.department}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Mail className="w-5 h-5" />
                    <span>{user.email}</span>
                  </div>
                </div>
              </>
            )}
          </div>
          <div className="flex space-x-3">
            {isEditing ? (
              <>
                <button
                  onClick={handleSave}
                  className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
                >
                  <Save className="w-5 h-5" />
                </button>
                <button
                  onClick={handleCancel}
                  className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </>
            ) : (
              <button
                onClick={() => setIsEditing(true)}
                className="bg-white/20 hover:bg-white/30 p-2 rounded-lg transition-colors"
              >
                <Edit3 className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <stat.icon className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</p>
            <p className="text-sm text-gray-600">{stat.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Skills & Interests */}
        <div className="lg:col-span-2 space-y-8">
          {/* Skills */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-semibold text-gray-900">Skills</h2>
              {!isEditing && (
                <button className="text-blue-600 hover:text-blue-800 text-sm font-medium">
                  Edit
                </button>
              )}
            </div>
            <div className="flex flex-wrap gap-2">
              {user.skills?.map((skill, index) => (
                <span key={index} className="bg-blue-100 text-blue-700 px-3 py-1 rounded-lg text-sm font-medium">
                  {skill}
                </span>
              ))}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Recent Activity</h2>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                    activity.type === 'join' ? 'bg-blue-100' :
                    activity.type === 'event' ? 'bg-green-100' :
                    activity.type === 'idea' ? 'bg-purple-100' : 'bg-gray-100'
                  }`}>
                    {activity.type === 'join' ? <Users className="w-4 h-4 text-blue-600" /> :
                     activity.type === 'event' ? <Calendar className="w-4 h-4 text-green-600" /> :
                     activity.type === 'idea' ? <Lightbulb className="w-4 h-4 text-purple-600" /> :
                     <User className="w-4 h-4 text-gray-600" />}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{activity.action}</p>
                    <p className="text-sm text-gray-500">{activity.date}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Achievements</h2>
          <div className="space-y-4">
            {achievements.map((achievement, index) => (
              <div key={index} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                <div className={`w-10 h-10 bg-${achievement.color}-100 rounded-lg flex items-center justify-center flex-shrink-0`}>
                  <Award className={`w-5 h-5 text-${achievement.color}-600`} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-gray-900">{achievement.title}</p>
                  <p className="text-sm text-gray-600 mb-1">{achievement.description}</p>
                  <p className="text-xs text-gray-500">{achievement.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}