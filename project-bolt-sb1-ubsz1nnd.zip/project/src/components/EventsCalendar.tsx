import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Users, Star, Filter, Plus } from 'lucide-react';
import { useTheme } from '../context/ThemeContext';

const events = [
  {
    id: 1,
    title: 'Tech Fest 2024',
    date: '2024-01-15',
    time: '09:00 AM',
    location: 'Main Auditorium',
    category: 'events',
    description: 'Annual technology festival with competitions, workshops, and exhibitions',
    organizer: 'Technical Committee',
    attendees: 245,
    maxAttendees: 300,
    isRegistered: false,
    image: 'https://images.pexels.com/photos/1181671/pexels-photo-1181671.jpeg'
  },
  {
    id: 2,
    title: 'Environmental Cleanup Drive',
    date: '2024-01-18',
    time: '07:00 AM',
    location: 'Campus Grounds',
    category: 'environmental',
    description: 'Join us in making our campus cleaner and greener',
    organizer: 'Eco Warriors',
    attendees: 67,
    maxAttendees: 100,
    isRegistered: true,
    image: 'https://images.pexels.com/photos/2547565/pexels-photo-2547565.jpeg'
  },
  {
    id: 3,
    title: 'Basketball Championship',
    date: '2024-01-20',
    time: '04:00 PM',
    location: 'Sports Complex',
    category: 'sports',
    description: 'Inter-college basketball championship finals',
    organizer: 'Sports Committee',
    attendees: 189,
    maxAttendees: 200,
    isRegistered: false,
    image: 'https://images.pexels.com/photos/1752757/pexels-photo-1752757.jpeg'
  },
  {
    id: 4,
    title: 'Leadership Summit',
    date: '2024-01-22',
    time: '10:00 AM',
    location: 'Conference Hall',
    category: 'leadership',
    description: 'Learn from industry leaders and develop your leadership skills',
    organizer: 'Student Council',
    attendees: 78,
    maxAttendees: 120,
    isRegistered: true,
    image: 'https://images.pexels.com/photos/1595391/pexels-photo-1595391.jpeg'
  },
  {
    id: 5,
    title: 'Startup Pitch Competition',
    date: '2024-01-25',
    time: '02:00 PM',
    location: 'Innovation Hub',
    category: 'entrepreneurship',
    description: 'Present your startup ideas and win exciting prizes',
    organizer: 'Entrepreneurs Hub',
    attendees: 34,
    maxAttendees: 50,
    isRegistered: false,
    image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg'
  }
];

export default function EventsCalendar() {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [registeredEvents, setRegisteredEvents] = useState<number[]>([2, 4]);
  const { getTheme } = useTheme();

  const categories = [
    { id: 'all', label: 'All Events', color: 'gray' },
    { id: 'events', label: 'College Events', color: 'purple' },
    { id: 'technical', label: 'Technical', color: 'blue' },
    { id: 'environmental', label: 'Environmental', color: 'green' },
    { id: 'sports', label: 'Sports', color: 'red' },
    { id: 'leadership', label: 'Leadership', color: 'yellow' },
    { id: 'entrepreneurship', label: 'Entrepreneurship', color: 'orange' }
  ];

  const filteredEvents = events.filter(event => 
    selectedCategory === 'all' || event.category === selectedCategory
  );

  const handleRegister = (eventId: number) => {
    setRegisteredEvents(prev => 
      prev.includes(eventId) 
        ? prev.filter(id => id !== eventId)
        : [...prev, eventId]
    );
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Events Calendar</h1>
            <p className="text-gray-600">Discover events, showcase your talents, and connect with your community</p>
          </div>
          <div className="mt-4 md:mt-0">
            <button className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center space-x-2">
              <Plus className="w-5 h-5" />
              <span>Propose Event</span>
            </button>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedCategory === category.id
                  ? `bg-${category.color}-500 text-white`
                  : `bg-${category.color}-100 text-${category.color}-700 hover:bg-${category.color}-200`
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {filteredEvents.map(event => {
          const theme = getTheme(event.category as any);
          const isRegistered = registeredEvents.includes(event.id);
          const spotsLeft = event.maxAttendees - event.attendees;
          
          return (
            <div key={event.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden border border-gray-100">
              {/* Event Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={event.image}
                  alt={event.title}
                  className="w-full h-full object-cover"
                />
                <div className={`absolute inset-0 bg-gradient-to-t ${theme.primary} opacity-70`} />
                <div className="absolute top-4 right-4">
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${theme.secondary} ${theme.accent}`}>
                    {event.category.charAt(0).toUpperCase() + event.category.slice(1)}
                  </span>
                </div>
                <div className="absolute bottom-4 left-4 right-4">
                  <h3 className="text-xl font-bold text-white mb-2">{event.title}</h3>
                  <p className="text-white/90 text-sm line-clamp-2">{event.description}</p>
                </div>
              </div>

              {/* Event Details */}
              <div className="p-6">
                <div className="grid grid-cols-2 gap-4 mb-4">
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Calendar className="w-4 h-4" />
                      <span>{formatDate(event.date)}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Clock className="w-4 h-4" />
                      <span>{event.time}</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <MapPin className="w-4 h-4" />
                      <span>{event.location}</span>
                    </div>
                    <div className="flex items-center space-x-2 text-sm text-gray-600">
                      <Users className="w-4 h-4" />
                      <span>{event.attendees}/{event.maxAttendees} attending</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="text-sm text-gray-600">
                    <span className="font-medium">Organized by:</span> {event.organizer}
                  </div>
                  <div className={`text-xs font-semibold px-2 py-1 rounded-full ${
                    spotsLeft > 20 ? 'bg-green-100 text-green-700' :
                    spotsLeft > 5 ? 'bg-yellow-100 text-yellow-700' :
                    spotsLeft > 0 ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-700'
                  }`}>
                    {spotsLeft > 0 ? `${spotsLeft} spots left` : 'Event full'}
                  </div>
                </div>

                {/* Registration Button */}
                <button
                  onClick={() => handleRegister(event.id)}
                  disabled={spotsLeft === 0}
                  className={`w-full py-3 px-4 rounded-lg font-semibold transition-colors ${
                    spotsLeft === 0
                      ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      : isRegistered
                      ? 'bg-green-100 text-green-700 hover:bg-green-200'
                      : `bg-gradient-to-r ${theme.primary} text-white hover:opacity-90`
                  }`}
                >
                  {spotsLeft === 0 
                    ? 'Event Full' 
                    : isRegistered 
                    ? '✓ Registered' 
                    : 'Register Now'
                  }
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {filteredEvents.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No events found</h3>
          <p className="text-gray-600">Try adjusting your filter criteria</p>
        </div>
      )}
    </div>
  );
}