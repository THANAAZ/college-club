import React from 'react';
import { Brain, TrendingUp, Users, Target, Star } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export default function AIInsights() {
  const { user } = useAuth();

  const recommendations = [
    {
      type: 'club',
      title: 'Photography Club',
      reason: 'Based on your interest in creative activities',
      confidence: 92,
      icon: Star,
      color: 'purple'
    },
    {
      type: 'skill',
      title: 'Public Speaking Workshop',
      reason: 'Enhance your leadership potential',
      confidence: 87,
      icon: TrendingUp,
      color: 'blue'
    },
    {
      type: 'collaboration',
      title: 'Coding + Design Team',
      reason: 'Perfect match for your technical skills',
      confidence: 95,
      icon: Users,
      color: 'green'
    },
    {
      type: 'event',
      title: 'Innovation Challenge',
      reason: 'Aligns with your problem-solving abilities',
      confidence: 89,
      icon: Target,
      color: 'orange'
    }
  ];

  const insights = [
    'You\'re most active in technical clubs - consider exploring cultural activities for balance',
    'Your leadership skills show great potential - student council positions may interest you',
    'Based on your activity, you might enjoy mentoring freshers in the coding club'
  ];

  return (
    <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl p-8">
      <div className="flex items-center mb-6">
        <div className="w-10 h-10 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center mr-4">
          <Brain className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-2xl font-bold text-gray-900">AI Recommendations</h2>
          <p className="text-gray-600">Personalized suggestions to accelerate your growth</p>
        </div>
      </div>

      {/* Recommendations Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {recommendations.map((rec, index) => (
          <div key={index} className="bg-white rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <div className={`w-8 h-8 bg-${rec.color}-100 rounded-lg flex items-center justify-center`}>
                <rec.icon className={`w-4 h-4 text-${rec.color}-600`} />
              </div>
              <div className="text-right">
                <span className={`text-xs font-semibold px-2 py-1 bg-${rec.color}-100 text-${rec.color}-700 rounded-full`}>
                  {rec.confidence}% match
                </span>
              </div>
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">{rec.title}</h3>
            <p className="text-sm text-gray-600">{rec.reason}</p>
          </div>
        ))}
      </div>

      {/* Insights */}
      <div className="bg-white rounded-xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Personal Growth Insights</h3>
        <div className="space-y-3">
          {insights.map((insight, index) => (
            <div key={index} className="flex items-start space-x-3 p-3 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
              <div className="w-2 h-2 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mt-2 flex-shrink-0" />
              <p className="text-gray-700">{insight}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}