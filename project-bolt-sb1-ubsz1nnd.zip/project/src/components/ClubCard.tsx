import React, { useState } from 'react';
import { Users, MapPin, Clock, Star, CheckCircle, UserPlus, Eye, X } from 'lucide-react';
import { useTheme, ClubCategory } from '../context/ThemeContext';

interface Club {
  id: string;
  name: string;
  category: ClubCategory;
  head: string;
  members: number;
  totalSeats: number;
  description: string;
  skills: string[];
  developSkills: string[];
  roles: string[];
  rules: string[];
  image: string;
}

interface ClubCardProps {
  club: Club;
  isJoined: boolean;
  onJoin: () => void;
  onLeave: () => void;
}

export default function ClubCard({ club, isJoined, onJoin, onLeave }: ClubCardProps) {
  const [showDetails, setShowDetails] = useState(false);
  const { getTheme } = useTheme();
  const theme = getTheme(club.category);
  
  const availableSeats = club.totalSeats - club.members;
  const isFullyBooked = availableSeats <= 0;

  return (
    <>
      <div className={`bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden border border-gray-100 ${theme.hover}`}>
        {/* Club Image */}
        <div className="relative h-48 overflow-hidden">
          <img
            src={club.image}
            alt={club.name}
            className="w-full h-full object-cover"
          />
          <div className={`absolute inset-0 bg-gradient-to-t ${theme.primary} opacity-80`} />
          <div className="absolute top-4 right-4">
            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${theme.secondary} ${theme.accent}`}>
              {club.category.charAt(0).toUpperCase() + club.category.slice(1)}
            </span>
          </div>
          <div className="absolute bottom-4 left-4 right-4">
            <h3 className="text-xl font-bold text-white mb-1">{club.name}</h3>
            <p className="text-white/90 text-sm">{club.description}</p>
          </div>
        </div>

        {/* Club Info */}
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-4 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <Users className="w-4 h-4" />
                <span>{club.members}/{club.totalSeats}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Star className="w-4 h-4" />
                <span>{club.head}</span>
              </div>
            </div>
            <div className={`text-xs font-semibold px-2 py-1 rounded-full ${
              availableSeats > 5 ? 'bg-green-100 text-green-700' :
              availableSeats > 0 ? 'bg-yellow-100 text-yellow-700' :
              'bg-red-100 text-red-700'
            }`}>
              {isFullyBooked ? 'Full' : `${availableSeats} seats left`}
            </div>
          </div>

          {/* Skills Preview */}
          <div className="mb-4">
            <p className="text-xs font-medium text-gray-500 mb-2">Required Skills</p>
            <div className="flex flex-wrap gap-1">
              {club.skills.slice(0, 3).map((skill, index) => (
                <span key={index} className={`text-xs px-2 py-1 ${theme.secondary} ${theme.accent} rounded`}>
                  {skill}
                </span>
              ))}
              {club.skills.length > 3 && (
                <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded">
                  +{club.skills.length - 3} more
                </span>
              )}
            </div>
          </div>

          {/* Actions */}
          <div className="flex space-x-3">
            <button
              onClick={() => setShowDetails(true)}
              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
            >
              <Eye className="w-4 h-4" />
              <span>View Details</span>
            </button>
            
            {isJoined ? (
              <button
                onClick={onLeave}
                className="flex-1 bg-red-100 hover:bg-red-200 text-red-700 py-2 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Leave Club</span>
              </button>
            ) : (
              <button
                onClick={onJoin}
                disabled={isFullyBooked}
                className={`flex-1 py-2 px-4 rounded-lg font-medium transition-colors flex items-center justify-center space-x-2 ${
                  isFullyBooked
                    ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                    : `bg-gradient-to-r ${theme.primary} text-white hover:opacity-90`
                }`}
              >
                <UserPlus className="w-4 h-4" />
                <span>{isFullyBooked ? 'Full' : 'Join Club'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Detailed Modal */}
      {showDetails && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-gray-900">{club.name}</h2>
              <button
                onClick={() => setShowDetails(false)}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Club Head & Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-500 mb-1">Club Head</p>
                  <p className="font-semibold text-gray-900">{club.head}</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-500 mb-1">Members</p>
                  <p className="font-semibold text-gray-900">{club.members}/{club.totalSeats}</p>
                </div>
              </div>

              {/* Skills Required */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Skills Required</h3>
                <div className="flex flex-wrap gap-2">
                  {club.skills.map((skill, index) => (
                    <span key={index} className={`px-3 py-1 ${theme.secondary} ${theme.accent} rounded-lg text-sm font-medium`}>
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Skills You'll Develop */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Skills You'll Develop</h3>
                <div className="flex flex-wrap gap-2">
                  {club.developSkills.map((skill, index) => (
                    <span key={index} className="px-3 py-1 bg-green-100 text-green-700 rounded-lg text-sm font-medium">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Available Roles */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Available Roles</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {club.roles.map((role, index) => (
                    <div key={index} className="flex items-center space-x-2 p-2 bg-gray-50 rounded-lg">
                      <div className="w-2 h-2 bg-blue-500 rounded-full" />
                      <span className="text-sm font-medium text-gray-700">{role}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Rules */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Club Rules</h3>
                <div className="space-y-2">
                  {club.rules.map((rule, index) => (
                    <div key={index} className="flex items-start space-x-2">
                      <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2 flex-shrink-0" />
                      <span className="text-sm text-gray-600">{rule}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-4 border-t border-gray-200">
                {isJoined ? (
                  <button
                    onClick={() => {
                      onLeave();
                      setShowDetails(false);
                    }}
                    className="w-full bg-red-100 hover:bg-red-200 text-red-700 py-3 px-6 rounded-lg font-semibold transition-colors"
                  >
                    Leave Club
                  </button>
                ) : (
                  <button
                    onClick={() => {
                      onJoin();
                      setShowDetails(false);
                    }}
                    disabled={isFullyBooked}
                    className={`w-full py-3 px-6 rounded-lg font-semibold transition-colors ${
                      isFullyBooked
                        ? 'bg-gray-200 text-gray-400 cursor-not-allowed'
                        : `bg-gradient-to-r ${theme.primary} text-white hover:opacity-90`
                    }`}
                  >
                    {isFullyBooked ? 'Club is Full' : 'Join Club'}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}