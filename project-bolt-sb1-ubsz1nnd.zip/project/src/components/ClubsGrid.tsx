import React, { useState } from 'react';
import { Search, Filter, Users, MapPin, Clock, Star, CheckCircle, UserPlus } from 'lucide-react';
import { useTheme, ClubCategory } from '../context/ThemeContext';
import { useAuth } from '../context/AuthContext';
import ClubCard from './ClubCard';

const clubs = [
  {
    id: 'coding-club',
    name: 'Coding Club',
    category: 'technical' as ClubCategory,
    head: 'Sarah Chen',
    members: 45,
    totalSeats: 50,
    description: 'Build amazing projects and learn cutting-edge technologies',
    skills: ['JavaScript', 'Python', 'React', 'Node.js'],
    developSkills: ['Full-stack Development', 'Problem Solving', 'Teamwork'],
    roles: ['Frontend Developer', 'Backend Developer', 'Project Manager'],
    rules: ['Attend weekly meetings', 'Contribute to projects', 'Help fellow members'],
    image: 'https://images.pexels.com/photos/270408/pexels-photo-270408.jpeg'
  },
  {
    id: 'eco-warriors',
    name: 'Eco Warriors',
    category: 'environmental' as ClubCategory,
    head: 'Mike Green',
    members: 32,
    totalSeats: 40,
    description: 'Making our campus and community more sustainable',
    skills: ['Environmental Science', 'Project Management'],
    developSkills: ['Sustainability', 'Community Outreach', 'Research'],
    roles: ['Research Coordinator', 'Event Organizer', 'Communications Lead'],
    rules: ['Participate in monthly cleanups', 'Promote eco-awareness', 'Lead by example'],
    image: 'https://images.pexels.com/photos/1108572/pexels-photo-1108572.jpeg'
  },
  {
    id: 'basketball-team',
    name: 'Basketball Team',
    category: 'sports' as ClubCategory,
    head: 'Jordan Smith',
    members: 18,
    totalSeats: 20,
    description: 'Competitive basketball team representing our college',
    skills: ['Basketball', 'Team Sports', 'Physical Fitness'],
    developSkills: ['Teamwork', 'Leadership', 'Discipline', 'Physical Endurance'],
    roles: ['Point Guard', 'Shooting Guard', 'Forward', 'Center'],
    rules: ['Daily practice attendance', 'Maintain academic standards', 'Team first mentality'],
    image: 'https://images.pexels.com/photos/1752757/pexels-photo-1752757.jpeg'
  },
  {
    id: 'student-council',
    name: 'Student Council',
    category: 'leadership' as ClubCategory,
    head: 'Emma Davis',
    members: 12,
    totalSeats: 15,
    description: 'Voice of students, driving positive changes in college',
    skills: ['Leadership', 'Public Speaking', 'Policy Making'],
    developSkills: ['Strategic Thinking', 'Negotiation', 'Event Management'],
    roles: ['President', 'Vice President', 'Secretary', 'Treasurer'],
    rules: ['Represent student interests', 'Organize college events', 'Maintain transparency'],
    image: 'https://images.pexels.com/photos/1595391/pexels-photo-1595391.jpeg'
  },
  {
    id: 'entrepreneurs-hub',
    name: 'Entrepreneurs Hub',
    category: 'entrepreneurship' as ClubCategory,
    head: 'Alex Rodriguez',
    members: 28,
    totalSeats: 35,
    description: 'Turn your ideas into successful ventures',
    skills: ['Business Development', 'Marketing', 'Finance'],
    developSkills: ['Innovation', 'Risk Management', 'Networking', 'Pitch Presentation'],
    roles: ['Business Analyst', 'Marketing Lead', 'Finance Manager', 'Operations Head'],
    rules: ['Pitch monthly business ideas', 'Mentor fellow entrepreneurs', 'Network actively'],
    image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg'
  },
  {
    id: 'disciplinary-committee',
    name: 'Disciplinary Committee',
    category: 'disciplinary' as ClubCategory,
    head: 'Prof. Robert Wilson',
    members: 8,
    totalSeats: 10,
    description: 'Ensuring fair and ethical conduct across campus',
    skills: ['Legal Knowledge', 'Conflict Resolution', 'Ethics'],
    developSkills: ['Critical Thinking', 'Mediation', 'Decision Making'],
    roles: ['Chairperson', 'Secretary', 'Student Representative', 'Faculty Advisor'],
    rules: ['Maintain confidentiality', 'Fair judgment', 'Follow due process'],
    image: 'https://images.pexels.com/photos/5668882/pexels-photo-5668882.jpeg'
  }
];

export default function ClubsGrid() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ClubCategory | 'all'>('all');
  const { setTheme } = useTheme();
  const { user, updateUser } = useAuth();

  const categories = [
    { id: 'all', label: 'All Clubs', color: 'gray' },
    { id: 'technical', label: 'Technical', color: 'blue' },
    { id: 'environmental', label: 'Environmental', color: 'green' },
    { id: 'sports', label: 'Sports & Cultural', color: 'red' },
    { id: 'leadership', label: 'Leadership', color: 'yellow' },
    { id: 'entrepreneurship', label: 'Entrepreneurship', color: 'orange' },
    { id: 'disciplinary', label: 'Disciplinary', color: 'gray' }
  ];

  const filteredClubs = clubs.filter(club => {
    const matchesSearch = club.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         club.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || club.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleCategoryChange = (category: ClubCategory | 'all') => {
    setSelectedCategory(category);
    if (category !== 'all') {
      setTheme(category);
    }
  };

  const handleJoinClub = (clubId: string) => {
    if (user) {
      const updatedClubs = [...(user.enrolledClubs || []), clubId];
      updateUser({ enrolledClubs: updatedClubs });
    }
  };

  const handleLeaveClub = (clubId: string) => {
    if (user) {
      const updatedClubs = user.enrolledClubs?.filter(id => id !== clubId) || [];
      updateUser({ enrolledClubs: updatedClubs });
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Clubs & Committees</h1>
        <p className="text-gray-600">Discover your passion, develop your skills, and grow with like-minded peers</p>
      </div>

      {/* Search and Filter */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search clubs by name or description..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
          <div className="flex items-center space-x-2">
            <Filter className="w-5 h-5 text-gray-400" />
            <span className="text-sm font-medium text-gray-700">Filter:</span>
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2">
          {categories.map(category => (
            <button
              key={category.id}
              onClick={() => handleCategoryChange(category.id as ClubCategory | 'all')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                selectedCategory === category.id
                  ? `bg-${category.color}-500 text-white`
                  : `bg-${category.color}-100 text-${category.color}-700 hover:bg-${category.color}-200`
              }`}
            >
              {category.label}
            </button>
          ))}
        </div>
      </div>

      {/* Clubs Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredClubs.map(club => (
          <ClubCard
            key={club.id}
            club={club}
            isJoined={user?.enrolledClubs?.includes(club.id) || false}
            onJoin={() => handleJoinClub(club.id)}
            onLeave={() => handleLeaveClub(club.id)}
          />
        ))}
      </div>

      {filteredClubs.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No clubs found</h3>
          <p className="text-gray-600">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
}