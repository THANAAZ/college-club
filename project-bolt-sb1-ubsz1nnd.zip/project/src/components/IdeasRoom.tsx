import React, { useState } from 'react';
import { Plus, ThumbsUp, MessageCircle, Lightbulb, TrendingUp, Siren as Fire, Clock, User } from 'lucide-react';

const ideas = [
  {
    id: 1,
    title: 'AI-Powered Study Groups',
    description: 'Create study groups using AI to match students with similar learning styles and schedules. This would help students find the perfect study partners.',
    author: 'Sarah Chen',
    category: 'Academic',
    votes: 45,
    comments: 12,
    timeAgo: '2 hours ago',
    trending: true,
    tags: ['AI', 'Study', 'Collaboration']
  },
  {
    id: 2,
    title: 'Sustainable Campus Food Initiative',
    description: 'Partner with local organic farms to provide fresh, sustainable meals in the cafeteria while reducing food waste through composting programs.',
    author: 'Mike Green',
    category: 'Environmental',
    votes: 38,
    comments: 8,
    timeAgo: '5 hours ago',
    trending: false,
    tags: ['Sustainability', 'Food', 'Environment']
  },
  {
    id: 3,
    title: 'Inter-College Esports League',
    description: 'Organize a competitive esports league between different colleges with popular games like Valorant, League of Legends, and CS:GO.',
    author: 'Alex Johnson',
    category: 'Sports & Entertainment',
    votes: 62,
    comments: 24,
    timeAgo: '1 day ago',
    trending: true,
    tags: ['Gaming', 'Competition', 'Inter-College']
  },
  {
    id: 4,
    title: 'Mental Health Support Bot',
    description: 'Develop a chatbot that provides 24/7 mental health support, resources, and connects students with counselors when needed.',
    author: 'Emma Davis',
    category: 'Wellness',
    votes: 29,
    comments: 6,
    timeAgo: '3 days ago',
    trending: false,
    tags: ['Mental Health', 'Technology', 'Support']
  },
  {
    id: 5,
    title: 'Student Startup Incubator',
    description: 'Create an on-campus incubator where students can work on their startup ideas with mentorship from faculty and industry experts.',
    author: 'Jordan Smith',
    category: 'Entrepreneurship',
    votes: 71,
    comments: 18,
    timeAgo: '1 week ago',
    trending: true,
    tags: ['Startup', 'Mentorship', 'Innovation']
  }
];

export default function IdeasRoom() {
  const [showProposalForm, setShowProposalForm] = useState(false);
  const [votedIdeas, setVotedIdeas] = useState<number[]>([]);
  const [sortBy, setSortBy] = useState('trending');

  const handleVote = (ideaId: number) => {
    setVotedIdeas(prev => 
      prev.includes(ideaId) 
        ? prev.filter(id => id !== ideaId)
        : [...prev, ideaId]
    );
  };

  const sortedIdeas = [...ideas].sort((a, b) => {
    switch (sortBy) {
      case 'trending':
        return b.trending ? 1 : -1;
      case 'votes':
        return b.votes - a.votes;
      case 'recent':
        return new Date(b.timeAgo).getTime() - new Date(a.timeAgo).getTime();
      default:
        return 0;
    }
  });

  const categoryColors = {
    'Academic': 'bg-blue-100 text-blue-700',
    'Environmental': 'bg-green-100 text-green-700',
    'Sports & Entertainment': 'bg-red-100 text-red-700',
    'Wellness': 'bg-purple-100 text-purple-700',
    'Entrepreneurship': 'bg-orange-100 text-orange-700'
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Header */}
      <div className="mb-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Ideas Room</h1>
            <p className="text-gray-600">Share your innovative ideas and help shape the future of our college</p>
          </div>
          <button
            onClick={() => setShowProposalForm(true)}
            className="mt-4 md:mt-0 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity flex items-center space-x-2"
          >
            <Plus className="w-5 h-5" />
            <span>Propose Idea</span>
          </button>
        </div>

        {/* Sort Options */}
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium text-gray-700">Sort by:</span>
          <div className="flex space-x-2">
            {[
              { id: 'trending', label: 'Trending', icon: Fire },
              { id: 'votes', label: 'Most Voted', icon: TrendingUp },
              { id: 'recent', label: 'Recent', icon: Clock }
            ].map(option => (
              <button
                key={option.id}
                onClick={() => setSortBy(option.id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-lg font-medium transition-colors ${
                  sortBy === option.id
                    ? 'bg-blue-100 text-blue-700'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <option.icon className="w-4 h-4" />
                <span>{option.label}</span>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Ideas List */}
      <div className="space-y-6">
        {sortedIdeas.map(idea => {
          const isVoted = votedIdeas.includes(idea.id);
          
          return (
            <div key={idea.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 p-6 border border-gray-100">
              {/* Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center space-x-3 mb-2">
                    <h3 className="text-xl font-bold text-gray-900">{idea.title}</h3>
                    {idea.trending && (
                      <span className="bg-red-100 text-red-600 px-2 py-1 rounded-full text-xs font-semibold flex items-center space-x-1">
                        <Fire className="w-3 h-3" />
                        <span>Trending</span>
                      </span>
                    )}
                  </div>
                  <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                    <div className="flex items-center space-x-1">
                      <User className="w-4 h-4" />
                      <span>{idea.author}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="w-4 h-4" />
                      <span>{idea.timeAgo}</span>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      categoryColors[idea.category as keyof typeof categoryColors] || 'bg-gray-100 text-gray-700'
                    }`}>
                      {idea.category}
                    </span>
                  </div>
                </div>
              </div>

              {/* Description */}
              <p className="text-gray-700 mb-4 leading-relaxed">{idea.description}</p>

              {/* Tags */}
              <div className="flex flex-wrap gap-2 mb-4">
                {idea.tags.map((tag, index) => (
                  <span key={index} className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs font-medium">
                    #{tag}
                  </span>
                ))}
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <button
                    onClick={() => handleVote(idea.id)}
                    className={`flex items-center space-x-2 px-4 py-2 rounded-lg font-medium transition-colors ${
                      isVoted
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    <ThumbsUp className={`w-4 h-4 ${isVoted ? 'fill-current' : ''}`} />
                    <span>{idea.votes + (isVoted ? 1 : 0)}</span>
                  </button>
                  <button className="flex items-center space-x-2 px-4 py-2 rounded-lg font-medium bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors">
                    <MessageCircle className="w-4 h-4" />
                    <span>{idea.comments}</span>
                  </button>
                </div>
                <button className="text-blue-600 hover:text-blue-800 font-medium text-sm">
                  View Details →
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Proposal Form Modal */}
      {showProposalForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black bg-opacity-50">
          <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 p-6 flex items-center justify-between rounded-t-2xl">
              <h2 className="text-2xl font-bold text-gray-900">Propose New Idea</h2>
              <button
                onClick={() => setShowProposalForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            
            <form className="p-6 space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Idea Title</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Give your idea a catchy title..."
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="">Select a category</option>
                  <option value="academic">Academic</option>
                  <option value="environmental">Environmental</option>
                  <option value="sports">Sports & Entertainment</option>
                  <option value="wellness">Wellness</option>
                  <option value="entrepreneurship">Entrepreneurship</option>
                  <option value="technology">Technology</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  rows={5}
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Describe your idea in detail. What problem does it solve? How would it work?"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
                <input
                  type="text"
                  className="w-full px-4 py-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Add tags separated by commas (e.g., innovation, sustainability, tech)"
                />
              </div>

              <div className="flex space-x-4">
                <button
                  type="button"
                  onClick={() => setShowProposalForm(false)}
                  className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  onClick={() => setShowProposalForm(false)}
                  className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
                >
                  Propose Idea
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}