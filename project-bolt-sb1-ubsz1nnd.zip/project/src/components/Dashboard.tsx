import React from 'react';
import { Users, Calendar, Lightbulb, TrendingUp, Award, Clock } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import AIInsights from './AIInsights';

export default function Dashboard() {
  const { user } = useAuth();

  const stats = [
    { label: 'Clubs Joined', value: user?.enrolledClubs?.length || 0, icon: Users, color: 'blue' },
    { label: 'Events Attended', value: 12, icon: Calendar, color: 'green' },
    { label: 'Ideas Proposed', value: 3, icon: Lightbulb, color: 'yellow' },
    { label: 'Skills Gained', value: user?.skills?.length || 0, icon: TrendingUp, color: 'purple' }
  ];

  const recentActivities = [
    { title: 'Joined Coding Club', time: '2 hours ago', type: 'join' },
    { title: 'Attended Tech Fest 2024', time: '1 day ago', type: 'event' },
    { title: 'Proposed new workshop idea', time: '3 days ago', type: 'idea' },
    { title: 'Completed Leadership Training', time: '1 week ago', type: 'achievement' }
  ];

  const upcomingEvents = [
    { name: 'Freshers Welcome', date: 'Dec 20', category: 'events' },
    { name: 'Coding Bootcamp', date: 'Dec 22', category: 'technical' },
    { name: 'Environmental Drive', date: 'Dec 25', category: 'environmental' }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">Welcome back, {user?.name?.split(' ')[0]}!</h1>
            <p className="text-blue-100 text-lg">Ready to grow together? Explore clubs, events, and opportunities.</p>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <Award className="w-16 h-16 text-yellow-300" />
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-500 text-sm font-medium">{stat.label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{stat.value}</p>
              </div>
              <div className={`w-12 h-12 bg-${stat.color}-100 rounded-lg flex items-center justify-center`}>
                <stat.icon className={`w-6 h-6 text-${stat.color}-600`} />
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activities */}
        <div className="lg:col-span-2">
          <div className="bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-semibold text-gray-900">Recent Activities</h2>
            </div>
            <div className="p-6 space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-center space-x-4 p-3 hover:bg-gray-50 rounded-lg transition-colors">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                    activity.type === 'join' ? 'bg-blue-100' :
                    activity.type === 'event' ? 'bg-green-100' :
                    activity.type === 'idea' ? 'bg-yellow-100' : 'bg-purple-100'
                  }`}>
                    {activity.type === 'join' ? <Users className="w-5 h-5 text-blue-600" /> :
                     activity.type === 'event' ? <Calendar className="w-5 h-5 text-green-600" /> :
                     activity.type === 'idea' ? <Lightbulb className="w-5 h-5 text-yellow-600" /> :
                     <Award className="w-5 h-5 text-purple-600" />}
                  </div>
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{activity.title}</p>
                    <p className="text-sm text-gray-500 flex items-center">
                      <Clock className="w-4 h-4 mr-1" />
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Quick Actions & Upcoming Events */}
        <div className="space-y-6">
          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
            <div className="space-y-3">
              <Link to="/clubs" className="block w-full bg-blue-50 hover:bg-blue-100 text-blue-700 p-3 rounded-lg transition-colors">
                <Users className="w-5 h-5 inline mr-2" />
                Browse Clubs
              </Link>
              <Link to="/events" className="block w-full bg-green-50 hover:bg-green-100 text-green-700 p-3 rounded-lg transition-colors">
                <Calendar className="w-5 h-5 inline mr-2" />
                View Events
              </Link>
              <Link to="/ideas" className="block w-full bg-yellow-50 hover:bg-yellow-100 text-yellow-700 p-3 rounded-lg transition-colors">
                <Lightbulb className="w-5 h-5 inline mr-2" />
                Share Ideas
              </Link>
            </div>
          </div>

          {/* Upcoming Events */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Upcoming Events</h3>
            <div className="space-y-3">
              {upcomingEvents.map((event, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-900">{event.name}</p>
                    <p className="text-sm text-gray-500">{event.date}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    event.category === 'events' ? 'bg-purple-500' :
                    event.category === 'technical' ? 'bg-blue-500' :
                    'bg-green-500'
                  }`} />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* AI Insights */}
      <AIInsights />
    </div>
  );
}