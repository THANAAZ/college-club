import React, { createContext, useContext, useState, ReactNode } from 'react';

export type ClubCategory = 'technical' | 'environmental' | 'sports' | 'leadership' | 'entrepreneurship' | 'disciplinary' | 'events';

export const themeColors = {
  technical: {
    primary: 'from-blue-500 to-blue-600',
    secondary: 'bg-blue-100',
    accent: 'text-blue-700',
    hover: 'hover:bg-blue-200'
  },
  environmental: {
    primary: 'from-green-500 to-green-600',
    secondary: 'bg-green-100',
    accent: 'text-green-700',
    hover: 'hover:bg-green-200'
  },
  sports: {
    primary: 'from-red-500 to-red-600',
    secondary: 'bg-red-100',
    accent: 'text-red-700',
    hover: 'hover:bg-red-200'
  },
  leadership: {
    primary: 'from-yellow-500 to-yellow-600',
    secondary: 'bg-yellow-100',
    accent: 'text-yellow-700',
    hover: 'hover:bg-yellow-200'
  },
  entrepreneurship: {
    primary: 'from-orange-500 to-orange-600',
    secondary: 'bg-orange-100',
    accent: 'text-orange-700',
    hover: 'hover:bg-orange-200'
  },
  disciplinary: {
    primary: 'from-gray-800 to-gray-900',
    secondary: 'bg-gray-100',
    accent: 'text-gray-700',
    hover: 'hover:bg-gray-200'
  },
  events: {
    primary: 'from-purple-500 via-pink-500 to-red-500',
    secondary: 'bg-gradient-to-r from-purple-100 via-pink-100 to-red-100',
    accent: 'text-purple-700',
    hover: 'hover:bg-gradient-to-r hover:from-purple-200 hover:via-pink-200 hover:to-red-200'
  }
};

interface ThemeContextType {
  currentTheme: ClubCategory;
  setTheme: (theme: ClubCategory) => void;
  getTheme: (category: ClubCategory) => typeof themeColors.technical;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [currentTheme, setCurrentTheme] = useState<ClubCategory>('technical');

  const setTheme = (theme: ClubCategory) => {
    setCurrentTheme(theme);
  };

  const getTheme = (category: ClubCategory) => {
    return themeColors[category];
  };

  return (
    <ThemeContext.Provider value={{ currentTheme, setTheme, getTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}