export interface User {
  id: string;
  name: string;
  email: string;
  year: 'Freshman' | 'Sophomore' | 'Junior' | 'Senior';
  branch: string;
  avatar?: string;
  skills: string[];
  interests: string[];
  joinedClubs: string[];
  role: 'student' | 'admin' | 'club_head';
}

export interface Club {
  id: string;
  name: string;
  category: ClubCategory;
  description: string;
  head: string;
  headContact: string;
  currentMembers: number;
  maxMembers: number;
  roles: string[];
  rules: string[];
  requiredSkills: string[];
  skillsToLearn: string[];
  isActive: boolean;
  joinedDate?: string;
  nextMeeting?: string;
  achievements: string[];
}

export type ClubCategory = 
  | 'technical' 
  | 'environmental' 
  | 'sports' 
  | 'leadership' 
  | 'entrepreneurship' 
  | 'disciplinary' 
  | 'events';

export interface Event {
  id: string;
  title: string;
  description: string;
  date: string;
  time: string;
  location: string;
  organizer: string;
  category: ClubCategory;
  isOpenToAll: boolean;
  registeredCount: number;
  maxParticipants?: number;
  requirements?: string[];
  rewards?: string[];
  status: 'upcoming' | 'ongoing' | 'completed';
}

export interface Idea {
  id: string;
  title: string;
  description: string;
  proposedBy: string;
  category: ClubCategory;
  votes: number;
  comments: Comment[];
  status: 'proposed' | 'under_review' | 'approved' | 'rejected';
  createdAt: string;
}

export interface Comment {
  id: string;
  userId: string;
  userName: string;
  content: string;
  timestamp: string;
}

export interface CollaborationProject {
  id: string;
  title: string;
  description: string;
  clubs: string[];
  skills: string[];
  teamSize: number;
  currentMembers: string[];
  status: 'open' | 'in_progress' | 'completed';
  deadline?: string;
}