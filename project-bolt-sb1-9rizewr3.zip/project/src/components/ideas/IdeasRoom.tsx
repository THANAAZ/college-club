import React, { useState } from 'react';
import { Plus, Search, TrendingUp, MessageSquare, ThumbsUp } from 'lucide-react';
import { mockIdeas } from '../../data/mockData';
import { Idea } from '../../types';
import { getCategoryEmoji } from '../../utils/helpers';
import IdeaCard from './IdeaCard';
import NewIdeaModal from './NewIdeaModal';

interface IdeasRoomProps {
  onVoteIdea: (ideaId: string) => void;
  onCommentIdea: (ideaId: string, comment: string) => void;
}

const IdeasRoom: React.FC<IdeasRoomProps> = ({ onVoteIdea, onCommentIdea }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState<'recent' | 'popular' | 'status'>('recent');
  const [showNewIdeaModal, setShowNewIdeaModal] = useState(false);

  const filteredAndSortedIdeas = mockIdeas
    .filter(idea => 
      idea.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      idea.description.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      switch (sortBy) {
        case 'popular':
          return b.votes - a.votes;
        case 'status':
          const statusOrder = { approved: 0, under_review: 1, proposed: 2, rejected: 3 };
          return statusOrder[a.status] - statusOrder[b.status];
        case 'recent':
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Ideas Room 💡</h1>
        <p className="text-purple-100">Share your innovative ideas, vote on proposals, and shape the future of our community</p>
      </div>

      {/* Search and Controls */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 mb-6">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search ideas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            />
          </div>

          {/* Sort Dropdown */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'recent' | 'popular' | 'status')}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
          >
            <option value="recent">Most Recent</option>
            <option value="popular">Most Popular</option>
            <option value="status">By Status</option>
          </select>

          {/* New Idea Button */}
          <button
            onClick={() => setShowNewIdeaModal(true)}
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg hover:from-purple-600 hover:to-pink-700 transition-all transform hover:scale-105"
          >
            <Plus className="w-4 h-4" />
            <span>Share Idea</span>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{mockIdeas.length}</div>
            <div className="text-sm text-gray-600">Total Ideas</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{mockIdeas.filter(i => i.status === 'approved').length}</div>
            <div className="text-sm text-gray-600">Approved</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-yellow-600">{mockIdeas.filter(i => i.status === 'under_review').length}</div>
            <div className="text-sm text-gray-600">Under Review</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{mockIdeas.reduce((acc, idea) => acc + idea.votes, 0)}</div>
            <div className="text-sm text-gray-600">Total Votes</div>
          </div>
        </div>
      </div>

      {/* Ideas Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredAndSortedIdeas.map(idea => (
          <IdeaCard
            key={idea.id}
            idea={idea}
            onVote={() => onVoteIdea(idea.id)}
            onComment={(comment) => onCommentIdea(idea.id, comment)}
          />
        ))}
      </div>

      {/* No Ideas */}
      {filteredAndSortedIdeas.length === 0 && (
        <div className="text-center py-12">
          <TrendingUp className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No ideas found</h3>
          <p className="text-gray-600 mb-4">Be the first to share your innovative idea!</p>
          <button
            onClick={() => setShowNewIdeaModal(true)}
            className="px-6 py-3 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition-colors"
          >
            Share Your Idea
          </button>
        </div>
      )}

      {/* New Idea Modal */}
      {showNewIdeaModal && (
        <NewIdeaModal onClose={() => setShowNewIdeaModal(false)} />
      )}
    </div>
  );
};

export default IdeasRoom;