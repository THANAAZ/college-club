import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Users, Award, ExternalLink, UserPlus } from 'lucide-react';
import { Event } from '../../types';
import { getCategoryEmoji, formatDate, formatTime } from '../../utils/helpers';

interface EventCardProps {
  event: Event;
  onRegister: () => void;
}

const EventCard: React.FC<EventCardProps> = ({ event, onRegister }) => {
  const [isRegistered, setIsRegistered] = useState(false);
  
  const handleRegister = () => {
    setIsRegistered(true);
    onRegister();
  };

  const getStatusBadge = () => {
    switch (event.status) {
      case 'upcoming':
        return <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">Upcoming</span>;
      case 'ongoing':
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full animate-pulse">Live Now</span>;
      case 'completed':
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full">Completed</span>;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105 overflow-hidden">
      {/* Header */}
      <div className="p-6 pb-4">
        <div className="flex items-start justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className="text-2xl">{getCategoryEmoji(event.category)}</span>
            <div>
              <h3 className="font-bold text-lg text-gray-900">{event.title}</h3>
              <p className="text-sm text-gray-600">by {event.organizer}</p>
            </div>
          </div>
          {getStatusBadge()}
        </div>

        <p className="text-gray-700 text-sm mb-4 line-clamp-2">{event.description}</p>

        {/* Event Details */}
        <div className="space-y-2 mb-4">
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(event.date)}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <Clock className="w-4 h-4" />
            <span>{formatTime(event.time)}</span>
          </div>
          <div className="flex items-center space-x-2 text-sm text-gray-600">
            <MapPin className="w-4 h-4" />
            <span>{event.location}</span>
          </div>
        </div>

        {/* Participants */}
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Users className="w-4 h-4 text-blue-500" />
            <span className="text-sm text-gray-600">
              {event.registeredCount} registered
              {event.maxParticipants && ` of ${event.maxParticipants}`}
            </span>
          </div>
          {event.isOpenToAll && (
            <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">
              Open to All
            </span>
          )}
        </div>

        {/* Progress Bar (if max participants) */}
        {event.maxParticipants && (
          <div className="mb-4">
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-green-500 h-2 rounded-full transition-all"
                style={{ width: `${Math.min((event.registeredCount / event.maxParticipants) * 100, 100)}%` }}
              ></div>
            </div>
          </div>
        )}

        {/* Requirements */}
        {event.requirements && event.requirements.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-gray-500 mb-2">Requirements:</p>
            <div className="flex flex-wrap gap-1">
              {event.requirements.map((req, index) => (
                <span key={index} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                  {req}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Rewards */}
        {event.rewards && event.rewards.length > 0 && (
          <div className="mb-4">
            <p className="text-xs text-gray-500 mb-2">Rewards:</p>
            <div className="space-y-1">
              {event.rewards.map((reward, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <Award className="w-3 h-3 text-yellow-500" />
                  <span className="text-xs text-gray-700">{reward}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex space-x-2">
          <button className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
            <ExternalLink className="w-4 h-4" />
            <span className="text-sm">View Details</span>
          </button>
          
          {event.status === 'upcoming' && (
            <button
              onClick={handleRegister}
              disabled={isRegistered || (event.maxParticipants && event.registeredCount >= event.maxParticipants)}
              className={`flex items-center justify-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                isRegistered
                  ? 'bg-green-500 text-white cursor-default'
                  : event.maxParticipants && event.registeredCount >= event.maxParticipants
                  ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  : 'bg-blue-500 text-white hover:bg-blue-600'
              }`}
            >
              {isRegistered ? (
                <>
                  <Award className="w-4 h-4" />
                  <span className="text-sm">Registered</span>
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  <span className="text-sm">Register</span>
                </>
              )}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default EventCard;