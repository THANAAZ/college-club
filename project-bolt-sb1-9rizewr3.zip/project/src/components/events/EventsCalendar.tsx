import React, { useState } from 'react';
import { Calendar, Clock, MapPin, Users, Filter, Plus, Search } from 'lucide-react';
import { mockEvents } from '../../data/mockData';
import { Event } from '../../types';
import { getCategoryEmoji, getCategoryName, formatDate, formatTime } from '../../utils/helpers';
import EventCard from './EventCard';

interface EventsCalendarProps {
  onRegisterEvent: (eventId: string) => void;
}

const EventsCalendar: React.FC<EventsCalendarProps> = ({ onRegisterEvent }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedFilter, setSelectedFilter] = useState<'all' | 'upcoming' | 'registered'>('all');

  const filteredEvents = mockEvents.filter(event => {
    const matchesSearch = event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         event.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || 
                         (selectedFilter === 'upcoming' && event.status === 'upcoming') ||
                         (selectedFilter === 'registered'); // Mock registered events
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-500 to-teal-600 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Events Calendar</h1>
        <p className="text-green-100">Discover events, showcase your talents, and connect with the community</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search events..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          {/* Filter Dropdown */}
          <select
            value={selectedFilter}
            onChange={(e) => setSelectedFilter(e.target.value as 'all' | 'upcoming' | 'registered')}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
          >
            <option value="all">All Events</option>
            <option value="upcoming">Upcoming Events</option>
            <option value="registered">My Registered Events</option>
          </select>
        </div>

        {/* Event Stats */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{mockEvents.length}</div>
            <div className="text-sm text-gray-600">Total Events</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{mockEvents.filter(e => e.status === 'upcoming').length}</div>
            <div className="text-sm text-gray-600">Upcoming</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{mockEvents.filter(e => e.isOpenToAll).length}</div>
            <div className="text-sm text-gray-600">Open to All</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{mockEvents.reduce((acc, e) => acc + e.registeredCount, 0)}</div>
            <div className="text-sm text-gray-600">Total Participants</div>
          </div>
        </div>
      </div>

      {/* Create Event Button */}
      <div className="flex justify-end">
        <button className="flex items-center space-x-2 px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors">
          <Plus className="w-4 h-4" />
          <span>Propose Event</span>
        </button>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredEvents.map(event => (
          <EventCard
            key={event.id}
            event={event}
            onRegister={() => onRegisterEvent(event.id)}
          />
        ))}
      </div>

      {/* No Events */}
      {filteredEvents.length === 0 && (
        <div className="text-center py-12">
          <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No events found</h3>
          <p className="text-gray-600 mb-4">Try adjusting your search or filter criteria</p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedFilter('all');
            }}
            className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
          >
            Show All Events
          </button>
        </div>
      )}
    </div>
  );
};

export default EventsCalendar;