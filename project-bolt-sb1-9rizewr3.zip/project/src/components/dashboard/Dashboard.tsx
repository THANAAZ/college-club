import React from 'react';
import { Users, Calendar, Lightbulb, TrendingUp, Award, Clock } from 'lucide-react';
import { mockUser, mockClubs, mockEvents } from '../../data/mockData';
import { getCategoryEmoji, getCategoryColor, generateAISuggestions } from '../../utils/helpers';
import StatsCard from './StatsCard';
import ActivityFeed from './ActivityFeed';
import QuickActions from './QuickActions';

interface DashboardProps {
  onTabChange: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onTabChange }) => {
  const userClubs = mockClubs.filter(club => mockUser.joinedClubs.includes(club.id));
  const upcomingEvents = mockEvents.filter(event => event.status === 'upcoming').slice(0, 3);
  const aiSuggestions = generateAISuggestions(mockUser.skills, mockUser.interests);

  const stats = [
    {
      title: 'Joined Clubs',
      value: userClubs.length.toString(),
      icon: Users,
      color: 'from-blue-500 to-blue-600',
      onClick: () => onTabChange('clubs')
    },
    {
      title: 'Upcoming Events',
      value: upcomingEvents.length.toString(),
      icon: Calendar,
      color: 'from-green-500 to-green-600',
      onClick: () => onTabChange('events')
    },
    {
      title: 'Ideas Proposed',
      value: '2',
      icon: Lightbulb,
      color: 'from-yellow-500 to-yellow-600',
      onClick: () => onTabChange('ideas')
    },
    {
      title: 'Skills Developed',
      value: mockUser.skills.length.toString(),
      icon: TrendingUp,
      color: 'from-purple-500 to-purple-600',
      onClick: () => onTabChange('settings')
    }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Welcome Header */}
      <div className="bg-gradient-to-r from-blue-500 to-indigo-600 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Welcome back, {mockUser.name}! 👋</h1>
        <p className="text-blue-100">Ready to grow together? Check out what's new in your clubs and events.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* My Clubs */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-gray-900">My Clubs</h2>
            <button
              onClick={() => onTabChange('clubs')}
              className="text-blue-600 hover:text-blue-800 font-medium"
            >
              View All
            </button>
          </div>
          
          <div className="space-y-4">
            {userClubs.map((club) => (
              <div key={club.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center space-x-3">
                  <span className="text-2xl">{getCategoryEmoji(club.category)}</span>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{club.name}</h3>
                    <p className="text-sm text-gray-600">{club.currentMembers} members • Next meeting: {club.nextMeeting ? new Date(club.nextMeeting).toLocaleDateString() : 'TBD'}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${getCategoryColor(club.category)}`}></div>
                </div>
              </div>
            ))}
            
            {userClubs.length === 0 && (
              <div className="text-center py-8 text-gray-500">
                <Users className="w-12 h-12 mx-auto mb-3 text-gray-400" />
                <p>You haven't joined any clubs yet.</p>
                <button
                  onClick={() => onTabChange('clubs')}
                  className="mt-2 text-blue-600 hover:text-blue-800 font-medium"
                >
                  Explore Clubs
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Quick Actions & AI Suggestions */}
        <div className="space-y-6">
          <QuickActions onTabChange={onTabChange} />
          
          {/* AI Suggestions */}
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl p-6">
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <Award className="w-4 h-4 text-white" />
              </div>
              <h3 className="font-bold text-gray-900">AI Suggestions</h3>
            </div>
            <div className="space-y-3">
              {aiSuggestions.map((suggestion, index) => (
                <div key={index} className="p-3 bg-white rounded-lg border border-purple-100">
                  <p className="text-sm text-gray-700">{suggestion}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Upcoming Events */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-gray-900">Upcoming Events</h2>
          <button
            onClick={() => onTabChange('events')}
            className="text-blue-600 hover:text-blue-800 font-medium"
          >
            View Calendar
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {upcomingEvents.map((event) => (
            <div key={event.id} className="p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
              <div className="flex items-center space-x-2 mb-2">
                <span className="text-lg">{getCategoryEmoji(event.category)}</span>
                <h3 className="font-semibold text-gray-900">{event.title}</h3>
              </div>
              <p className="text-sm text-gray-600 mb-2">{event.description}</p>
              <div className="flex items-center space-x-2 text-xs text-gray-500">
                <Clock className="w-3 h-3" />
                <span>{new Date(event.date).toLocaleDateString()} at {event.time}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Activity Feed */}
      <ActivityFeed />
    </div>
  );
};

export default Dashboard;