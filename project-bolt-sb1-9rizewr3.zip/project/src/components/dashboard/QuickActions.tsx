import React from 'react';
import { Plus, Search, MessageSquare, Users } from 'lucide-react';

interface QuickActionsProps {
  onTabChange: (tab: string) => void;
}

const QuickActions: React.FC<QuickActionsProps> = ({ onTabChange }) => {
  const actions = [
    {
      label: 'Join Club',
      icon: Plus,
      color: 'from-blue-500 to-blue-600',
      onClick: () => onTabChange('clubs')
    },
    {
      label: 'Browse Events',
      icon: Search,
      color: 'from-green-500 to-green-600',
      onClick: () => onTabChange('events')
    },
    {
      label: 'Share Ideas',
      icon: MessageSquare,
      color: 'from-purple-500 to-purple-600',
      onClick: () => onTabChange('ideas')
    },
    {
      label: 'Collaborate',
      icon: Users,
      color: 'from-orange-500 to-orange-600',
      onClick: () => onTabChange('collaboration')
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h3 className="font-bold text-gray-900 mb-4">Quick Actions</h3>
      <div className="grid grid-cols-2 gap-3">
        {actions.map((action, index) => {
          const Icon = action.icon;
          return (
            <button
              key={index}
              onClick={action.onClick}
              className={`flex flex-col items-center space-y-2 p-4 rounded-lg bg-gradient-to-r ${action.color} text-white hover:shadow-lg transform hover:scale-105 transition-all`}
            >
              <Icon className="w-5 h-5" />
              <span className="text-xs font-medium">{action.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default QuickActions;