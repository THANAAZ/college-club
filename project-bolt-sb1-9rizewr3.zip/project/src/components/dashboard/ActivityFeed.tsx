import React from 'react';
import { Bell, Award, Users, Calendar } from 'lucide-react';

const ActivityFeed: React.FC = () => {
  const activities = [
    {
      id: 1,
      type: 'achievement',
      icon: Award,
      title: 'Code Crafters won Inter-college Hackathon!',
      description: 'Your club secured first place with the AI-powered study buddy project.',
      time: '2 hours ago',
      color: 'text-yellow-600'
    },
    {
      id: 2,
      type: 'membership',
      icon: Users,
      title: '5 new members joined Sports Excellence Club',
      description: 'The basketball team is getting stronger for the upcoming tournament.',
      time: '5 hours ago',
      color: 'text-blue-600'
    },
    {
      id: 3,
      type: 'event',
      icon: Calendar,
      title: 'Tree Plantation Drive registration opens tomorrow',
      description: 'Green Earth Initiative invites all students to participate.',
      time: '1 day ago',
      color: 'text-green-600'
    },
    {
      id: 4,
      type: 'notification',
      icon: Bell,
      title: 'Student Council meeting rescheduled',
      description: 'Next meeting moved to Friday 2 PM in the main conference room.',
      time: '2 days ago',
      color: 'text-purple-600'
    }
  ];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6">
      <h2 className="text-xl font-bold text-gray-900 mb-6">Campus Activity Feed</h2>
      
      <div className="space-y-4">
        {activities.map((activity) => {
          const Icon = activity.icon;
          return (
            <div key={activity.id} className="flex space-x-4 p-4 hover:bg-gray-50 rounded-lg transition-colors">
              <div className={`w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center ${activity.color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">{activity.title}</h3>
                <p className="text-sm text-gray-600 mt-1">{activity.description}</p>
                <p className="text-xs text-gray-500 mt-2">{activity.time}</p>
              </div>
            </div>
          );
        })}
      </div>
      
      <button className="w-full mt-4 py-2 text-blue-600 hover:text-blue-800 font-medium transition-colors">
        View All Activities
      </button>
    </div>
  );
};

export default ActivityFeed;