import React from 'react';
import { Home, Users, Calendar, Lightbulb, GitBranch, Settings, LogOut, Bell } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout: () => void;
  userName: string;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, onTabChange, onLogout, userName }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'clubs', label: 'Clubs & Committees', icon: Users },
    { id: 'events', label: 'Events Calendar', icon: Calendar },
    { id: 'ideas', label: 'Ideas Room', icon: Lightbulb },
    { id: 'collaboration', label: 'Collaboration', icon: GitBranch },
  ];

  return (
    <div className="w-64 bg-white shadow-lg h-screen flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          GrowTogether
        </h1>
        <p className="text-sm text-gray-600 mt-1">From freshers to leaders</p>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all transform hover:scale-105 ${
                isActive
                  ? 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span className="font-medium">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* User Profile & Actions */}
      <div className="p-4 border-t border-gray-200 space-y-2">
        <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center">
            <span className="text-white font-medium text-sm">
              {userName.charAt(0)}
            </span>
          </div>
          <div className="flex-1">
            <p className="font-medium text-gray-900 text-sm">{userName}</p>
            <p className="text-xs text-gray-600">Sophomore</p>
          </div>
          <button className="p-1 hover:bg-gray-200 rounded">
            <Bell className="w-4 h-4 text-gray-600" />
          </button>
        </div>

        <button
          onClick={() => onTabChange('settings')}
          className={`w-full flex items-center space-x-3 px-4 py-2 rounded-lg transition-colors ${
            activeTab === 'settings'
              ? 'bg-gray-100 text-gray-900'
              : 'text-gray-700 hover:bg-gray-100'
          }`}
        >
          <Settings className="w-4 h-4" />
          <span className="text-sm">Settings</span>
        </button>

        <button
          onClick={onLogout}
          className="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-600 hover:bg-red-50 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span className="text-sm">Logout</span>
        </button>
      </div>
    </div>
  );
};

export default Sidebar;