import React from 'react';
import { Users, Calendar, Target, Clock, UserPlus, ExternalLink } from 'lucide-react';
import { CollaborationProject } from '../../types';
import { getCategoryEmoji } from '../../utils/helpers';

interface CollaborationCardProps {
  project: CollaborationProject;
  onJoin: () => void;
}

const CollaborationCard: React.FC<CollaborationCardProps> = ({ project, onJoin }) => {
  const getStatusBadge = () => {
    switch (project.status) {
      case 'open':
        return <span className="px-2 py-1 bg-green-100 text-green-800 text-xs font-medium rounded-full">Open for Collaboration</span>;
      case 'in_progress':
        return <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs font-medium rounded-full">In Progress</span>;
      case 'completed':
        return <span className="px-2 py-1 bg-gray-100 text-gray-800 text-xs font-medium rounded-full">Completed</span>;
    }
  };

  const availableSpots = project.teamSize - project.currentMembers.length;

  return (
    <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105 p-6">
      {/* Header */}
      <div className="flex items-start justify-between mb-4">
        <div>
          <h3 className="font-bold text-xl text-gray-900 mb-1">{project.title}</h3>
          <div className="flex items-center space-x-2">
            {project.clubs.map((club, index) => (
              <span key={club} className="text-sm text-blue-600 font-medium">
                {club}{index < project.clubs.length - 1 && ' + '}
              </span>
            ))}
          </div>
        </div>
        {getStatusBadge()}
      </div>

      {/* Description */}
      <p className="text-gray-700 mb-4 line-clamp-3">{project.description}</p>

      {/* Clubs Involved */}
      <div className="mb-4">
        <p className="text-sm font-medium text-gray-700 mb-2">Collaborating Clubs:</p>
        <div className="flex flex-wrap gap-2">
          {project.clubs.map(club => (
            <span key={club} className="px-3 py-1 bg-blue-50 text-blue-700 text-sm rounded-full">
              🤝 {club}
            </span>
          ))}
        </div>
      </div>

      {/* Skills Needed */}
      <div className="mb-4">
        <p className="text-sm font-medium text-gray-700 mb-2">Skills Needed:</p>
        <div className="flex flex-wrap gap-2">
          {project.skills.map(skill => (
            <span key={skill} className="px-2 py-1 bg-purple-50 text-purple-700 text-xs rounded-full">
              {skill}
            </span>
          ))}
        </div>
      </div>

      {/* Team Progress */}
      <div className="mb-4">
        <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
          <span>Team Progress</span>
          <span>{project.currentMembers.length}/{project.teamSize} members</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div
            className="bg-orange-500 h-2 rounded-full transition-all"
            style={{ width: `${(project.currentMembers.length / project.teamSize) * 100}%` }}
          ></div>
        </div>
        {availableSpots > 0 && (
          <p className="text-xs text-green-600 mt-1">{availableSpots} spots available</p>
        )}
      </div>

      {/* Timeline */}
      {project.deadline && (
        <div className="flex items-center space-x-2 mb-4 text-sm text-gray-600">
          <Calendar className="w-4 h-4" />
          <span>Deadline: {new Date(project.deadline).toLocaleDateString()}</span>
        </div>
      )}

      {/* Action Buttons */}
      <div className="flex space-x-2">
        <button className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
          <ExternalLink className="w-4 h-4" />
          <span className="text-sm">View Details</span>
        </button>
        
        {project.status === 'open' && availableSpots > 0 && (
          <button
            onClick={onJoin}
            className="flex items-center justify-center space-x-2 px-4 py-2 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
          >
            <UserPlus className="w-4 h-4" />
            <span className="text-sm">Join Project</span>
          </button>
        )}
      </div>
    </div>
  );
};

export default CollaborationCard;