import React, { useState } from 'react';
import { Users, Search, Plus, GitBranch, Clock, Target } from 'lucide-react';
import { mockCollaborations } from '../../data/mockData';
import { CollaborationProject } from '../../types';
import CollaborationCard from './CollaborationCard';
import NewProjectModal from './NewProjectModal';

interface CollaborationHubProps {
  onJoinProject: (projectId: string) => void;
}

const CollaborationHub: React.FC<CollaborationHubProps> = ({ onJoinProject }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'open' | 'in_progress' | 'completed'>('all');
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);

  const filteredProjects = mockCollaborations.filter(project => {
    const matchesSearch = project.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         project.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesFilter = filterStatus === 'all' || project.status === filterStatus;
    
    return matchesSearch && matchesFilter;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-orange-500 to-red-600 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Collaboration Hub 🤝</h1>
        <p className="text-orange-100">Bridge clubs, combine skills, and create amazing projects together</p>
      </div>

      {/* Search and Controls */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col md:flex-row space-y-4 md:space-y-0 md:space-x-4 mb-6">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search projects, skills, or clubs..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
            />
          </div>

          {/* Status Filter */}
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as 'all' | 'open' | 'in_progress' | 'completed')}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          >
            <option value="all">All Projects</option>
            <option value="open">Open for Collaboration</option>
            <option value="in_progress">In Progress</option>
            <option value="completed">Completed</option>
          </select>

          {/* New Project Button */}
          <button
            onClick={() => setShowNewProjectModal(true)}
            className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg hover:from-orange-600 hover:to-red-700 transition-all transform hover:scale-105"
          >
            <Plus className="w-4 h-4" />
            <span>Start Project</span>
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{mockCollaborations.length}</div>
            <div className="text-sm text-gray-600">Total Projects</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{mockCollaborations.filter(p => p.status === 'open').length}</div>
            <div className="text-sm text-gray-600">Open Projects</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{mockCollaborations.filter(p => p.status === 'in_progress').length}</div>
            <div className="text-sm text-gray-600">In Progress</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">
              {mockCollaborations.reduce((acc, p) => acc + p.currentMembers.length, 0)}
            </div>
            <div className="text-sm text-gray-600">Active Collaborators</div>
          </div>
        </div>
      </div>

      {/* Featured Collaboration Opportunities */}
      <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6">
        <div className="flex items-center space-x-2 mb-4">
          <GitBranch className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">Why Collaborate?</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mb-3">
              <Users className="w-4 h-4 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Cross-Club Learning</h3>
            <p className="text-sm text-gray-600">Learn from seniors and peers across different clubs and domains</p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center mb-3">
              <Target className="w-4 h-4 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Skill Diversity</h3>
            <p className="text-sm text-gray-600">Combine technical, creative, and leadership skills for better outcomes</p>
          </div>
          <div className="bg-white rounded-lg p-4 shadow-sm">
            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center mb-3">
              <Clock className="w-4 h-4 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900 mb-2">Real Impact</h3>
            <p className="text-sm text-gray-600">Work on projects that make a difference in campus life and beyond</p>
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredProjects.map(project => (
          <CollaborationCard
            key={project.id}
            project={project}
            onJoin={() => onJoinProject(project.id)}
          />
        ))}
      </div>

      {/* No Projects */}
      {filteredProjects.length === 0 && (
        <div className="text-center py-12">
          <GitBranch className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No projects found</h3>
          <p className="text-gray-600 mb-4">Start a new collaboration project to bring different clubs together!</p>
          <button
            onClick={() => setShowNewProjectModal(true)}
            className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
          >
            Start New Project
          </button>
        </div>
      )}

      {/* New Project Modal */}
      {showNewProjectModal && (
        <NewProjectModal onClose={() => setShowNewProjectModal(false)} />
      )}
    </div>
  );
};

export default CollaborationHub;