import React, { useState } from 'react';
import { X, Users } from 'lucide-react';
import { mockClubs } from '../../data/mockData';

interface NewProjectModalProps {
  onClose: () => void;
}

const NewProjectModal: React.FC<NewProjectModalProps> = ({ onClose }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedClubs, setSelectedClubs] = useState<string[]>([]);
  const [skills, setSkills] = useState('');
  const [teamSize, setTeamSize] = useState(6);
  const [deadline, setDeadline] = useState('');

  const handleClubToggle = (clubName: string) => {
    setSelectedClubs(prev => 
      prev.includes(clubName) 
        ? prev.filter(c => c !== clubName)
        : [...prev, clubName]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle project creation
    console.log({
      title,
      description,
      clubs: selectedClubs,
      skills: skills.split(',').map(s => s.trim()),
      teamSize,
      deadline
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900">Start New Collaboration 🚀</h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
          <p className="text-gray-600 mt-2">Create a cross-club project and bring different skills together</p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Project Title */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Project Title *
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="Enter a compelling project title..."
              required
            />
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Project Description *
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
              placeholder="Describe your project, its goals, and expected outcomes..."
              required
            />
          </div>

          {/* Club Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Clubs to Collaborate *
            </label>
            <p className="text-xs text-gray-500 mb-3">Select at least 2 clubs to collaborate with</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {mockClubs.map(club => (
                <button
                  key={club.id}
                  type="button"
                  onClick={() => handleClubToggle(club.name)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    selectedClubs.includes(club.name)
                      ? 'border-orange-500 bg-orange-50 text-orange-800'
                      : 'border-gray-300 hover:border-gray-400'
                  }`}
                >
                  <div className="font-medium text-sm">{club.name}</div>
                  <div className="text-xs text-gray-500">{club.currentMembers} members</div>
                </button>
              ))}
            </div>
          </div>

          {/* Skills Needed */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Skills Needed *
            </label>
            <input
              type="text"
              value={skills}
              onChange={(e) => setSkills(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              placeholder="e.g., React Development, UI Design, Project Management, Marketing"
              required
            />
            <p className="text-xs text-gray-500 mt-1">Separate skills with commas</p>
          </div>

          {/* Team Size and Deadline */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Team Size
              </label>
              <div className="flex items-center space-x-3">
                <Users className="w-5 h-5 text-gray-400" />
                <input
                  type="range"
                  min="3"
                  max="15"
                  value={teamSize}
                  onChange={(e) => setTeamSize(parseInt(e.target.value))}
                  className="flex-1"
                />
                <span className="font-medium text-gray-900">{teamSize} members</span>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Project Deadline
              </label>
              <input
                type="date"
                value={deadline}
                onChange={(e) => setDeadline(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent"
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
          </div>

          {/* Guidelines */}
          <div className="bg-orange-50 rounded-lg p-4">
            <h4 className="font-medium text-orange-900 mb-2">Collaboration Guidelines</h4>
            <ul className="text-sm text-orange-800 space-y-1">
              <li>• Projects should benefit the campus community</li>
              <li>• Include diverse skills from different clubs</li>
              <li>• Provide clear roles and responsibilities</li>
              <li>• Regular progress updates are required</li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex space-x-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!title.trim() || !description.trim() || selectedClubs.length < 2 || !skills.trim()}
              className="flex-1 px-6 py-3 bg-gradient-to-r from-orange-500 to-red-600 text-white rounded-lg hover:from-orange-600 hover:to-red-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-all"
            >
              Start Collaboration
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NewProjectModal;