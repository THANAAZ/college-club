import React, { useState } from 'react';
import { Search, Filter, MapPin, Users, Crown, Calendar } from 'lucide-react';
import { mockClubs, mockUser } from '../../data/mockData';
import { Club, ClubCategory } from '../../types';
import { getCategoryColor, getCategoryEmoji, getCategoryName } from '../../utils/helpers';
import ClubCard from './ClubCard';

interface ClubsGridProps {
  onJoinClub: (clubId: string) => void;
  onLeaveClub: (clubId: string) => void;
}

const ClubsGrid: React.FC<ClubsGridProps> = ({ onJoinClub, onLeaveClub }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<ClubCategory | 'all'>('all');
  const [showAvailableOnly, setShowAvailableOnly] = useState(false);

  const categories: { value: ClubCategory | 'all'; label: string; emoji: string }[] = [
    { value: 'all', label: 'All Categories', emoji: '🏫' },
    { value: 'technical', label: getCategoryName('technical'), emoji: getCategoryEmoji('technical') },
    { value: 'environmental', label: getCategoryName('environmental'), emoji: getCategoryEmoji('environmental') },
    { value: 'sports', label: getCategoryName('sports'), emoji: getCategoryEmoji('sports') },
    { value: 'leadership', label: getCategoryName('leadership'), emoji: getCategoryEmoji('leadership') },
    { value: 'entrepreneurship', label: getCategoryName('entrepreneurship'), emoji: getCategoryEmoji('entrepreneurship') },
    { value: 'disciplinary', label: getCategoryName('disciplinary'), emoji: getCategoryEmoji('disciplinary') },
    { value: 'events', label: getCategoryName('events'), emoji: getCategoryEmoji('events') }
  ];

  const filteredClubs = mockClubs.filter(club => {
    const matchesSearch = club.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         club.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || club.category === selectedCategory;
    const hasAvailableSeats = !showAvailableOnly || club.currentMembers < club.maxMembers;
    
    return matchesSearch && matchesCategory && hasAvailableSeats;
  });

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl p-6 text-white">
        <h1 className="text-3xl font-bold mb-2">Clubs & Committees</h1>
        <p className="text-indigo-100">Discover your passion, develop your skills, and grow with like-minded peers</p>
      </div>

      {/* Search and Filters */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <div className="flex flex-col lg:flex-row space-y-4 lg:space-y-0 lg:space-x-4">
          {/* Search Bar */}
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search clubs, skills, or interests..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value as ClubCategory | 'all')}
            className="px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent min-w-[200px]"
          >
            {categories.map(category => (
              <option key={category.value} value={category.value}>
                {category.emoji} {category.label}
              </option>
            ))}
          </select>

          {/* Available Only Toggle */}
          <label className="flex items-center space-x-2 px-4 py-3 bg-gray-50 rounded-lg cursor-pointer">
            <input
              type="checkbox"
              checked={showAvailableOnly}
              onChange={(e) => setShowAvailableOnly(e.target.checked)}
              className="form-checkbox h-4 w-4 text-blue-600"
            />
            <span className="text-sm text-gray-700">Available seats only</span>
          </label>
        </div>

        {/* Quick Stats */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{mockClubs.length}</div>
            <div className="text-sm text-gray-600">Total Clubs</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-600">{mockClubs.filter(c => c.currentMembers < c.maxMembers).length}</div>
            <div className="text-sm text-gray-600">Open for Joining</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{mockUser.joinedClubs.length}</div>
            <div className="text-sm text-gray-600">My Clubs</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{mockClubs.reduce((acc, club) => acc + club.currentMembers, 0)}</div>
            <div className="text-sm text-gray-600">Active Members</div>
          </div>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap gap-2">
        {categories.map(category => (
          <button
            key={category.value}
            onClick={() => setSelectedCategory(category.value)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition-all transform hover:scale-105 ${
              selectedCategory === category.value
                ? 'bg-blue-500 text-white shadow-lg'
                : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            <span className="mr-2">{category.emoji}</span>
            {category.label}
          </button>
        ))}
      </div>

      {/* Clubs Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredClubs.map(club => (
          <ClubCard
            key={club.id}
            club={club}
            isJoined={mockUser.joinedClubs.includes(club.id)}
            onJoin={() => onJoinClub(club.id)}
            onLeave={() => onLeaveClub(club.id)}
          />
        ))}
      </div>

      {/* No Results */}
      {filteredClubs.length === 0 && (
        <div className="text-center py-12">
          <Filter className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No clubs found</h3>
          <p className="text-gray-600 mb-4">Try adjusting your search terms or filters</p>
          <button
            onClick={() => {
              setSearchTerm('');
              setSelectedCategory('all');
              setShowAvailableOnly(false);
            }}
            className="px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            Clear Filters
          </button>
        </div>
      )}
    </div>
  );
};

export default ClubsGrid;