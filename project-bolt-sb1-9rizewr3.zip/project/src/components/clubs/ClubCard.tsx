import React, { useState } from 'react';
import { Users, Crown, MapPin, Calendar, Award, CheckCircle, Plus, X, Eye } from 'lucide-react';
import { Club } from '../../types';
import { getCategoryColor, getCategoryEmoji, getCategoryName } from '../../utils/helpers';
import ClubModal from './ClubModal';

interface ClubCardProps {
  club: Club;
  isJoined: boolean;
  onJoin: () => void;
  onLeave: () => void;
}

const ClubCard: React.FC<ClubCardProps> = ({ club, isJoined, onJoin, onLeave }) => {
  const [showModal, setShowModal] = useState(false);
  const availableSeats = club.maxMembers - club.currentMembers;
  const isFullyBooked = availableSeats <= 0;

  return (
    <>
      <div className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105 overflow-hidden">
        {/* Header with Category Badge */}
        <div className={`h-2 ${getCategoryColor(club.category)}`}></div>
        
        <div className="p-6">
          {/* Club Header */}
          <div className="flex items-start justify-between mb-4">
            <div className="flex items-center space-x-3">
              <span className="text-3xl">{getCategoryEmoji(club.category)}</span>
              <div>
                <h3 className="font-bold text-xl text-gray-900">{club.name}</h3>
                <p className="text-sm text-gray-600">{getCategoryName(club.category)}</p>
              </div>
            </div>
            {club.isActive && (
              <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" title="Active Club"></div>
            )}
          </div>

          {/* Description */}
          <p className="text-gray-700 text-sm mb-4 line-clamp-3">{club.description}</p>

          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="flex items-center space-x-2">
              <Users className="w-4 h-4 text-blue-500" />
              <span className="text-sm text-gray-600">
                {club.currentMembers}/{club.maxMembers} members
              </span>
            </div>
            <div className="flex items-center space-x-2">
              <Crown className="w-4 h-4 text-yellow-500" />
              <span className="text-sm text-gray-600">{club.head}</span>
            </div>
          </div>

          {/* Progress Bar */}
          <div className="mb-4">
            <div className="flex justify-between items-center text-xs text-gray-600 mb-1">
              <span>Capacity</span>
              <span>{Math.round((club.currentMembers / club.maxMembers) * 100)}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className={`h-2 rounded-full transition-all ${
                  isFullyBooked 
                    ? 'bg-red-500' 
                    : availableSeats <= 5 
                    ? 'bg-yellow-500' 
                    : 'bg-green-500'
                }`}
                style={{ width: `${Math.min((club.currentMembers / club.maxMembers) * 100, 100)}%` }}
              ></div>
            </div>
          </div>

          {/* Seat Availability */}
          <div className="mb-4">
            {isFullyBooked ? (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                Fully Booked
              </span>
            ) : availableSeats <= 5 ? (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                {availableSeats} seats left
              </span>
            ) : (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                Open for joining
              </span>
            )}
          </div>

          {/* Skills Preview */}
          <div className="mb-4">
            <p className="text-xs text-gray-500 mb-2">Skills you'll learn:</p>
            <div className="flex flex-wrap gap-1">
              {club.skillsToLearn.slice(0, 3).map((skill) => (
                <span key={skill} className="px-2 py-1 bg-blue-50 text-blue-700 text-xs rounded-full">
                  {skill}
                </span>
              ))}
              {club.skillsToLearn.length > 3 && (
                <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full">
                  +{club.skillsToLearn.length - 3} more
                </span>
              )}
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-2">
            <button
              onClick={() => setShowModal(true)}
              className="flex-1 flex items-center justify-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Eye className="w-4 h-4" />
              <span className="text-sm">View Details</span>
            </button>
            
            {isJoined ? (
              <button
                onClick={onLeave}
                className="flex items-center justify-center space-x-2 px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors"
              >
                <X className="w-4 h-4" />
                <span className="text-sm">Leave</span>
              </button>
            ) : (
              <button
                onClick={onJoin}
                disabled={isFullyBooked}
                className={`flex items-center justify-center space-x-2 px-4 py-2 rounded-lg transition-colors ${
                  isFullyBooked
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                <Plus className="w-4 h-4" />
                <span className="text-sm">{isFullyBooked ? 'Full' : 'Join'}</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <ClubModal
          club={club}
          isJoined={isJoined}
          onJoin={onJoin}
          onLeave={onLeave}
          onClose={() => setShowModal(false)}
        />
      )}
    </>
  );
};

export default ClubCard;