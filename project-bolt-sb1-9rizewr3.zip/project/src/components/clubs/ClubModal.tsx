import React from 'react';
import { X, Users, Crown, Mail, Calendar, Award, Target, BookOpen, CheckCircle, Plus } from 'lucide-react';
import { Club } from '../../types';
import { getCategoryColor, getCategoryEmoji, getCategoryName } from '../../utils/helpers';

interface ClubModalProps {
  club: Club;
  isJoined: boolean;
  onJoin: () => void;
  onLeave: () => void;
  onClose: () => void;
}

const ClubModal: React.FC<ClubModalProps> = ({ club, isJoined, onJoin, onLeave, onClose }) => {
  const availableSeats = club.maxMembers - club.currentMembers;
  const isFullyBooked = availableSeats <= 0;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className={`p-6 text-white ${getCategoryColor(club.category)}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <span className="text-4xl">{getCategoryEmoji(club.category)}</span>
              <div>
                <h2 className="text-2xl font-bold">{club.name}</h2>
                <p className="opacity-90">{getCategoryName(club.category)}</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white hover:bg-opacity-20 rounded-full transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          {/* Status and Quick Info */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <Users className="w-5 h-5 text-blue-500" />
              <div>
                <p className="font-medium text-gray-900">{club.currentMembers}/{club.maxMembers}</p>
                <p className="text-sm text-gray-600">Members</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <Crown className="w-5 h-5 text-yellow-500" />
              <div>
                <p className="font-medium text-gray-900">{club.head}</p>
                <p className="text-sm text-gray-600">Club Head</p>
              </div>
            </div>
            
            <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <Calendar className="w-5 h-5 text-green-500" />
              <div>
                <p className="font-medium text-gray-900">
                  {club.nextMeeting ? new Date(club.nextMeeting).toLocaleDateString() : 'TBD'}
                </p>
                <p className="text-sm text-gray-600">Next Meeting</p>
              </div>
            </div>
          </div>

          {/* Description */}
          <div>
            <h3 className="text-lg font-semibold text-gray-900 mb-3">About the Club</h3>
            <p className="text-gray-700 leading-relaxed">{club.description}</p>
          </div>

          {/* Two Column Layout */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Left Column */}
            <div className="space-y-6">
              {/* Available Roles */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                  <Target className="w-5 h-5 mr-2 text-blue-500" />
                  Available Roles
                </h3>
                <div className="space-y-2">
                  {club.roles.map((role) => (
                    <div key={role} className="flex items-center space-x-2 p-2 bg-blue-50 rounded-lg">
                      <CheckCircle className="w-4 h-4 text-blue-600" />
                      <span className="text-sm text-blue-800">{role}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Required Skills */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                  <BookOpen className="w-5 h-5 mr-2 text-green-500" />
                  Required Skills
                </h3>
                <div className="flex flex-wrap gap-2">
                  {club.requiredSkills.map((skill) => (
                    <span key={skill} className="px-3 py-1 bg-green-100 text-green-800 text-sm rounded-full">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="space-y-6">
              {/* Skills to Learn */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                  <Award className="w-5 h-5 mr-2 text-purple-500" />
                  Skills You'll Develop
                </h3>
                <div className="flex flex-wrap gap-2">
                  {club.skillsToLearn.map((skill) => (
                    <span key={skill} className="px-3 py-1 bg-purple-100 text-purple-800 text-sm rounded-full">
                      {skill}
                    </span>
                  ))}
                </div>
              </div>

              {/* Club Rules */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">Club Guidelines</h3>
                <ul className="space-y-2">
                  {club.rules.map((rule, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <div className="w-2 h-2 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                      <span className="text-sm text-gray-700">{rule}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Achievements */}
          {club.achievements.length > 0 && (
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
                <Award className="w-5 h-5 mr-2 text-yellow-500" />
                Recent Achievements
              </h3>
              <div className="space-y-2">
                {club.achievements.map((achievement, index) => (
                  <div key={index} className="flex items-center space-x-2 p-3 bg-yellow-50 rounded-lg">
                    <Award className="w-4 h-4 text-yellow-600" />
                    <span className="text-sm text-yellow-800">{achievement}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contact Information */}
          <div className="bg-gray-50 rounded-lg p-4">
            <h3 className="font-semibold text-gray-900 mb-2">Contact Information</h3>
            <div className="flex items-center space-x-2">
              <Mail className="w-4 h-4 text-gray-600" />
              <a href={`mailto:${club.headContact}`} className="text-blue-600 hover:text-blue-800 text-sm">
                {club.headContact}
              </a>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex space-x-4 pt-4 border-t">
            <button
              onClick={onClose}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              Close
            </button>
            
            {isJoined ? (
              <button
                onClick={() => {
                  onLeave();
                  onClose();
                }}
                className="flex-1 px-6 py-3 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-colors flex items-center justify-center space-x-2"
              >
                <X className="w-4 h-4" />
                <span>Leave Club</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  if (!isFullyBooked) {
                    onJoin();
                    onClose();
                  }
                }}
                disabled={isFullyBooked}
                className={`flex-1 px-6 py-3 rounded-lg transition-colors flex items-center justify-center space-x-2 ${
                  isFullyBooked
                    ? 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    : 'bg-blue-500 text-white hover:bg-blue-600'
                }`}
              >
                <Plus className="w-4 h-4" />
                <span>{isFullyBooked ? 'Club Full' : 'Join Club'}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClubModal;