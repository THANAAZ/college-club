import React, { useState } from 'react';
import LoginForm from './components/auth/LoginForm';
import Sidebar from './components/layout/Sidebar';
import Dashboard from './components/dashboard/Dashboard';
import ClubsGrid from './components/clubs/ClubsGrid';
import EventsCalendar from './components/events/EventsCalendar';
import IdeasRoom from './components/ideas/IdeasRoom';
import CollaborationHub from './components/collaboration/CollaborationHub';
import { mockUser } from './data/mockData';

type ActiveTab = 'dashboard' | 'clubs' | 'events' | 'ideas' | 'collaboration' | 'settings';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');

  const handleLogin = async (email: string, password: string) => {
    setIsLoading(true);
    // Simulate login API call
    setTimeout(() => {
      if (email === 'arjun.sharma@college.edu' && password === 'password123') {
        setIsLoggedIn(true);
      } else {
        alert('Invalid credentials. Please use the demo credentials.');
      }
      setIsLoading(false);
    }, 1500);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setActiveTab('dashboard');
  };

  const handleJoinClub = (clubId: string) => {
    console.log('Joining club:', clubId);
    // Implement club joining logic
  };

  const handleLeaveClub = (clubId: string) => {
    console.log('Leaving club:', clubId);
    // Implement club leaving logic
  };

  const handleRegisterEvent = (eventId: string) => {
    console.log('Registering for event:', eventId);
    // Implement event registration logic
  };

  const handleVoteIdea = (ideaId: string) => {
    console.log('Voting on idea:', ideaId);
    // Implement idea voting logic
  };

  const handleCommentIdea = (ideaId: string, comment: string) => {
    console.log('Commenting on idea:', ideaId, comment);
    // Implement idea commenting logic
  };

  const handleJoinProject = (projectId: string) => {
    console.log('Joining collaboration project:', projectId);
    // Implement project joining logic
  };

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} isLoading={isLoading} />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard onTabChange={setActiveTab} />;
      case 'clubs':
        return <ClubsGrid onJoinClub={handleJoinClub} onLeaveClub={handleLeaveClub} />;
      case 'events':
        return <EventsCalendar onRegisterEvent={handleRegisterEvent} />;
      case 'ideas':
        return <IdeasRoom onVoteIdea={handleVoteIdea} onCommentIdea={handleCommentIdea} />;
      case 'collaboration':
        return <CollaborationHub onJoinProject={handleJoinProject} />;
      case 'settings':
        return (
          <div className="p-6">
            <div className="bg-white rounded-xl shadow-lg p-8">
              <h1 className="text-2xl font-bold text-gray-900 mb-6">Settings</h1>
              <div className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Profile Information</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
                      <input
                        type="text"
                        value={mockUser.name}
                        readOnly
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                      <input
                        type="email"
                        value={mockUser.email}
                        readOnly
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Year</label>
                      <input
                        type="text"
                        value={mockUser.year}
                        readOnly
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Branch</label>
                      <input
                        type="text"
                        value={mockUser.branch}
                        readOnly
                        className="w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-lg"
                      />
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {mockUser.skills.map(skill => (
                      <span key={skill} className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Interests</h3>
                  <div className="flex flex-wrap gap-2">
                    {mockUser.interests.map(interest => (
                      <span key={interest} className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                        {interest}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return <Dashboard onTabChange={setActiveTab} />;
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onLogout={handleLogout}
        userName={mockUser.name}
      />
      <main className="flex-1 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
}

export default App;