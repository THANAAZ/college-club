import { User, Club, Event, Idea, CollaborationProject } from '../types';

export const mockUser: User = {
  id: '1',
  name: 'Arjun Sharma',
  email: 'arjun.sharma@college.edu',
  year: 'Sophomore',
  branch: 'Computer Science',
  skills: ['JavaScript', 'React', 'Node.js'],
  interests: ['Web Development', 'AI/ML', 'Photography'],
  joinedClubs: ['1', '3'],
  role: 'student'
};

export const mockClubs: Club[] = [
  {
    id: '1',
    name: 'Code Crafters',
    category: 'technical',
    description: 'A community of passionate programmers building innovative solutions and learning cutting-edge technologies.',
    head: 'Priya Patel',
    headContact: 'priya.patel@college.edu',
    currentMembers: 45,
    maxMembers: 60,
    roles: ['Frontend Developer', 'Backend Developer', 'Mobile Developer', 'DevOps Engineer'],
    rules: ['Attend weekly meetings', 'Contribute to group projects', 'Help junior members'],
    requiredSkills: ['Basic Programming', 'Git/GitHub'],
    skillsToLearn: ['Advanced Frameworks', 'Cloud Computing', 'System Design'],
    isActive: true,
    nextMeeting: '2025-01-15T18:00:00',
    achievements: ['Won Inter-college Hackathon 2024', 'Published 5 open-source projects']
  },
  {
    id: '2',
    name: 'Green Earth Initiative',
    category: 'environmental',
    description: 'Dedicated to environmental conservation and promoting sustainable practices on campus.',
    head: 'Radhika Singh',
    headContact: 'radhika.singh@college.edu',
    currentMembers: 32,
    maxMembers: 50,
    roles: ['Environmental Advocate', 'Research Coordinator', 'Event Organizer'],
    rules: ['Participate in campus cleaning drives', 'Promote eco-friendly practices'],
    requiredSkills: ['Environmental Awareness', 'Communication'],
    skillsToLearn: ['Sustainability Planning', 'Research Methods', 'Policy Analysis'],
    isActive: true,
    nextMeeting: '2025-01-12T16:00:00',
    achievements: ['Planted 500+ trees', 'Reduced campus plastic usage by 40%']
  },
  {
    id: '3',
    name: 'Sports Excellence Club',
    category: 'sports',
    description: 'Promoting fitness, sportsmanship, and healthy competition among students.',
    head: 'Vikram Kumar',
    headContact: 'vikram.kumar@college.edu',
    currentMembers: 78,
    maxMembers: 100,
    roles: ['Team Captain', 'Coach Assistant', 'Equipment Manager', 'Event Coordinator'],
    rules: ['Regular training attendance', 'Fair play and sportsmanship'],
    requiredSkills: ['Basic Fitness', 'Team Spirit'],
    skillsToLearn: ['Advanced Techniques', 'Leadership', 'First Aid'],
    isActive: true,
    nextMeeting: '2025-01-10T17:00:00',
    achievements: ['Won 12 inter-college tournaments', 'State-level participation in 3 sports']
  },
  {
    id: '4',
    name: 'Student Council',
    category: 'leadership',
    description: 'Representative body working for student welfare and organizing campus-wide initiatives.',
    head: 'Ananya Gupta',
    headContact: 'ananya.gupta@college.edu',
    currentMembers: 15,
    maxMembers: 20,
    roles: ['Secretary', 'Treasurer', 'Public Relations', 'Event Coordinator'],
    rules: ['Attend all council meetings', 'Represent student interests'],
    requiredSkills: ['Leadership', 'Communication', 'Problem Solving'],
    skillsToLearn: ['Public Speaking', 'Event Management', 'Negotiation'],
    isActive: true,
    nextMeeting: '2025-01-08T14:00:00',
    achievements: ['Implemented 8 student welfare policies', 'Organized successful cultural fest']
  },
  {
    id: '5',
    name: 'Innovation Hub',
    category: 'entrepreneurship',
    description: 'Fostering entrepreneurial mindset and supporting startup ideas among students.',
    head: 'Rahul Mehta',
    headContact: 'rahul.mehta@college.edu',
    currentMembers: 28,
    maxMembers: 40,
    roles: ['Business Analyst', 'Marketing Lead', 'Tech Advisor', 'Mentor'],
    rules: ['Present innovative ideas monthly', 'Support fellow entrepreneurs'],
    requiredSkills: ['Business Acumen', 'Creative Thinking'],
    skillsToLearn: ['Business Planning', 'Pitching', 'Market Research'],
    isActive: true,
    nextMeeting: '2025-01-13T19:00:00',
    achievements: ['Launched 5 successful startups', 'Secured ₹2L in funding for student projects']
  },
  {
    id: '6',
    name: 'Disciplinary Committee',
    category: 'disciplinary',
    description: 'Maintaining campus discipline and ensuring adherence to institutional guidelines.',
    head: 'Prof. Sunita Rao',
    headContact: 'sunita.rao@college.edu',
    currentMembers: 12,
    maxMembers: 15,
    roles: ['Disciplinary Officer', 'Counselor', 'Mediator'],
    rules: ['Maintain confidentiality', 'Fair and unbiased decisions'],
    requiredSkills: ['Ethics', 'Communication', 'Problem Solving'],
    skillsToLearn: ['Conflict Resolution', 'Counseling', 'Administrative Skills'],
    isActive: true,
    nextMeeting: '2025-01-11T11:00:00',
    achievements: ['Resolved 150+ student issues', 'Maintained 95% campus discipline score']
  },
  {
    id: '7',
    name: 'TechFest Organizing Committee',
    category: 'events',
    description: 'Organizing the annual technical festival and managing college-wide celebrations.',
    head: 'Karthik Reddy',
    headContact: 'karthik.reddy@college.edu',
    currentMembers: 35,
    maxMembers: 50,
    roles: ['Event Manager', 'Logistics Coordinator', 'Sponsorship Lead', 'Marketing Head'],
    rules: ['Commit to event timeline', 'Collaborate across teams'],
    requiredSkills: ['Event Planning', 'Teamwork', 'Time Management'],
    skillsToLearn: ['Project Management', 'Budget Management', 'Vendor Relations'],
    isActive: true,
    nextMeeting: '2025-01-09T18:30:00',
    achievements: ['Organized TechFest 2024 with 5000+ participants', 'Managed ₹15L event budget']
  }
];

export const mockEvents: Event[] = [
  {
    id: '1',
    title: 'Annual Hackathon 2025',
    description: '48-hour coding marathon to solve real-world problems with innovative solutions.',
    date: '2025-02-15',
    time: '09:00',
    location: 'Main Auditorium',
    organizer: 'Code Crafters',
    category: 'technical',
    isOpenToAll: true,
    registeredCount: 120,
    maxParticipants: 200,
    requirements: ['Laptop', 'Programming Knowledge'],
    rewards: ['₹50,000 Cash Prize', 'Internship Opportunities'],
    status: 'upcoming'
  },
  {
    id: '2',
    title: 'Tree Plantation Drive',
    description: 'Campus-wide initiative to plant 200 saplings and create a greener environment.',
    date: '2025-01-20',
    time: '07:00',
    location: 'Campus Grounds',
    organizer: 'Green Earth Initiative',
    category: 'environmental',
    isOpenToAll: true,
    registeredCount: 85,
    status: 'upcoming'
  },
  {
    id: '3',
    title: 'Inter-Department Sports Meet',
    description: 'Annual sports competition featuring cricket, football, basketball, and athletics.',
    date: '2025-03-10',
    time: '08:00',
    location: 'Sports Complex',
    organizer: 'Sports Excellence Club',
    category: 'sports',
    isOpenToAll: true,
    registeredCount: 200,
    status: 'upcoming'
  }
];

export const mockIdeas: Idea[] = [
  {
    id: '1',
    title: 'AI-Powered Study Buddy App',
    description: 'Develop a mobile app that uses AI to help students with personalized study plans and doubt resolution.',
    proposedBy: 'Sneha Patel',
    category: 'technical',
    votes: 24,
    comments: [
      {
        id: '1',
        userId: '2',
        userName: 'Rahul Kumar',
        content: 'Great idea! I can help with the backend development.',
        timestamp: '2025-01-05T10:30:00'
      }
    ],
    status: 'approved',
    createdAt: '2025-01-03T14:20:00'
  },
  {
    id: '2',
    title: 'Campus Waste Segregation System',
    description: 'Implement a smart waste segregation system with IoT sensors and reward points for proper disposal.',
    proposedBy: 'Environmental Team',
    category: 'environmental',
    votes: 18,
    comments: [],
    status: 'under_review',
    createdAt: '2025-01-04T09:15:00'
  }
];

export const mockCollaborations: CollaborationProject[] = [
  {
    id: '1',
    title: 'Campus Food Delivery App',
    description: 'Cross-collaboration between coding and business clubs to create a food delivery solution for campus.',
    clubs: ['Code Crafters', 'Innovation Hub'],
    skills: ['Mobile Development', 'Business Strategy', 'UI/UX Design'],
    teamSize: 8,
    currentMembers: ['user1', 'user2', 'user3'],
    status: 'in_progress',
    deadline: '2025-04-15'
  },
  {
    id: '2',
    title: 'Smart Campus Navigation',
    description: 'AR-based campus navigation system combining tech skills with student council insights.',
    clubs: ['Code Crafters', 'Student Council'],
    skills: ['AR/VR Development', 'User Research', 'Project Management'],
    teamSize: 6,
    currentMembers: ['user4', 'user5'],
    status: 'open',
    deadline: '2025-05-30'
  }
];