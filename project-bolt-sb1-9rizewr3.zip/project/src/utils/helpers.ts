import { ClubCategory } from '../types';

export const getCategoryColor = (category: ClubCategory): string => {
  const colors = {
    technical: 'bg-blue-500',
    environmental: 'bg-green-500',
    sports: 'bg-red-500',
    leadership: 'bg-yellow-500',
    entrepreneurship: 'bg-orange-500',
    disciplinary: 'bg-gray-800',
    events: 'bg-gradient-to-r from-purple-500 to-pink-500'
  };
  return colors[category];
};

export const getCategoryEmoji = (category: ClubCategory): string => {
  const emojis = {
    technical: '🔵',
    environmental: '🟢',
    sports: '🔴',
    leadership: '🟡',
    entrepreneurship: '🟠',
    disciplinary: '⚫',
    events: '🌈'
  };
  return emojis[category];
};

export const getCategoryName = (category: ClubCategory): string => {
  const names = {
    technical: 'Technical/Academic',
    environmental: 'Environmental/Nature',
    sports: 'Sports/Cultural',
    leadership: 'Leadership/Student Council',
    entrepreneurship: 'Entrepreneurship/Innovation',
    disciplinary: 'Disciplinary/Formal',
    events: 'College-Wide Events'
  };
  return names[category];
};

export const formatDate = (dateString: string): string => {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-US', {
    weekday: 'short',
    year: 'numeric',
    month: 'short',
    day: 'numeric'
  });
};

export const formatTime = (timeString: string): string => {
  const time = new Date(`2000-01-01T${timeString}`);
  return time.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
};

export const getSkillLevel = (skills: string[]): 'Beginner' | 'Intermediate' | 'Advanced' => {
  if (skills.length <= 2) return 'Beginner';
  if (skills.length <= 5) return 'Intermediate';
  return 'Advanced';
};

export const generateAISuggestions = (userSkills: string[], userInterests: string[]) => {
  // Mock AI suggestions based on user profile
  return [
    "Based on your React skills, consider joining the Code Crafters club to work on advanced web projects.",
    "Your interest in photography makes you perfect for the TechFest Organizing Committee's media team.",
    "Consider collaborating on the Smart Campus Navigation project - it combines your tech skills with practical impact."
  ];
};